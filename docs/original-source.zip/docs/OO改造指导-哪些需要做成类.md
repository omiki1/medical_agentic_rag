# 函数式 → 面向对象 改造指导

**定位**：本项目（medical_disease_db，原 rag_system_v2 后端）当前为函数式写法，本指导用真实代码对照，告诉你**哪些模块需要做成类、做成什么类、怎么改**。按它改，代码会更规范、可测试、易维护。

> 使用方式：先看第一节“判断标准”，再按第二节“逐文件清单”对照你手头的代码，最后参考第三节的示例落地。

---

## 一、判断标准：一眼看出“该不该做成类”

不是所有函数都要改成类。判定用下面五条，**命中任意一条就建议做成类**：

| # | 判断标准 | 现在的症状示例 | 建议 |
|---|---------|--------------|------|
| 1 | **有可变状态** | 模块级 `llm = None` + `global llm` | 做成**单例类**，状态放实例属性 |
| 2 | **加载/持有昂贵资源** | 模型、DB 连接、Redis、检索器 | 做成**服务类/连接池类**，`__init__` 构造，懒加载内部化 |
| 3 | **每函数重复读配置 / 依赖同一组东西** | 每个函数都 `os.getenv('SECRET_KEY')` | 做成**类**，配置在 `__init__` 注入一次 |
| 4 | **返回裸 dict，结构不清晰** | `return {'code':200,'msg':'...','data':...}` | 配套做 **Response/Entity 类** |
| 5 | **一组强相关的函数互相调用** | JWT 的 create/verify、Hash 的 hash/verify | 收进同一个类，方法化 |

**不需要做成类的**（保持函数即可）：
- 纯计算、无状态、无副作用的一次性小工具 —— 可做 `@staticmethod`
- FastAPI 的**路由层**（controller 里的 `@router.get(...)`）—— 保持轻量即可，不必过度封装
- 简单工厂函数（如 `LoadChroma.load_chroma_conn`）—— 可保留为函数或改成类方法

---

## 二、逐文件改造清单（对照真实代码）

下表按“**强烈建议 → 可选**”排序，最后一列是改后形态。

### A. 强烈建议做成类（命中状态/资源/重复配置）

| 文件 | 现状（真实代码） | 问题 | 改后形态 |
|------|----------------|------|---------|
| `ai/LoadLLM.py` | `llm=None` + `global llm`，懒加载 ChatOpenAI | 模块级可变状态、`global`、读死配置 | **单例类 `LLMService`**，`get_instance()`，模型放 `self._llm` |
| `ai/LoadEmbeddingModel.py` | 同 LoadLLM 模式（推断） | 模型加载有状态 | **单例类 `EmbeddingService`** |
| `rag/RerankerUtil.py` | `reranker=None` + `global reranker`，`reranker_func(dict)` | 全局状态 + 裸 dict 参数 | **服务类 `RerankerService`**，`rerank(question, contexts, history)` |
| `rag/VectorRetriever.py` | 检索相关（推断有初始化） | 持有向量库资源 | **服务类 `VectorRetriever`** 或并入 `RetrievalPipeline` |
| `rag/BM25Retriever.py` | `get_bm25_index(load())` 散落调用 | 索引构建重复、依赖穿插 | **类 `BM25Index`**，一次性 build，`search()` 方法 |
| `common/JWTUtil.py` | 模块级 `load_dotenv()` + 每函数 `os.getenv` | 配置散落、无封装 | **类 `JWTManager`**，`__init__` 里读 secret/expire，方法 `create_access_token` / `verify_token` |
| `common/MySQLUtil.py` | 连接管理（推断为函数） | 连接散落 | **连接池类 `MySQLPool`** 或保持 util 但做成类方法 |
| `common/RedisUtil.py` | `get_redis_conn()` / `close_redis_conn(r)` 配对 | 连接生命周期裸奔 | **类 `RedisClient`（context manager）**，`with` 自动关闭 |
| `user/service/UserService.py` | 游离函数 `get_profile/send_email/register_user`，每处返回裸 dict | 无状态封装、重复 os.getenv、裸 dict | **类 `UserService`** + **统一 Response 类** |
| `chat/service/ChatService.py` | 同 UserService（推测） | 同上 | **类 `ChatService`** + Response |

### B. 可选做成类（本身还算合理）

| 文件 | 现状 | 建议 |
|------|------|------|
| `common/HashPwdUtil.py` | 你已示范改 `PasswordManager` | ✅ 已完成，作为全项目范例 |
| `ai/LoadChroma.py` | 纯净工厂 `load_chroma_conn()` | 可保留函数，或做 `ChromaFactory.create()` 类方法 |
| `user/controller/UserController.py` | `users_router` + `def ...` 路由 | 轻量即可；若要依赖注入可在路由函数里 `app.state.xxx` 取服务 |
| `user/dao/UsersDao.py` | DAO 层（数据访问） | 建议**保留函数式**即可，或用类 + 静态方法，看团队习惯 |
| `rag/HydeUtil.py` / `RRFUtil.py` / `SummaryHistory.py` | 纯算法工具 | 保持函数或 `@staticmethod` 类 |

---

## 三、改造示例（照此模式类推）

### 示例 1：有状态资源 → 单例类（`ai/LoadLLM.py` → `LLMService`）

**当前（函数式）**
```python
# ai/LoadLLM.py
from langchain_openai import ChatOpenAI
import os
from pydantic import SecretStr

llm = None                                  # 模块级可变状态

def load_model():
    global llm                              # global 跨文件污染
    if not llm:
        llm = ChatOpenAI(
            api_key=SecretStr(os.getenv('CHAT_OPENAI_API_KEY')),
            base_url='https://api.deepseek.com',
            model='deepseek-v4-flash',
            streaming=True,
            temperature=0.5, top_p=1,
        )
    return llm
```

**改后（单例类）**
```python
# ai/LLMService.py
from langchain_openai import ChatOpenAI
from pydantic import SecretStr
import os

class LLMService:
    """LLM 服务：懒加载 + 单例，模型状态封装在实例内。"""

    _instance = None                        # 类级：全局唯一实例

    def __init__(self, api_key=None, base_url=None, model=None, **kwargs):
        # 配置在构造时注入一次，不再到处 os.getenv
        self._api_key = api_key or os.getenv('CHAT_OPENAI_API_KEY')
        self._base_url = base_url or 'https://api.deepseek.com'
        self._model = model or 'deepseek-v4-flash'
        self._kwargs = kwargs
        self._llm = None                    # 实例级懒加载状态

    def get(self):
        """懒加载：首次调用才真正创建模型。"""
        if self._llm is None:
            self._llm = ChatOpenAI(
                api_key=SecretStr(self._api_key),
                base_url=self._base_url,
                model=self._model,
                streaming=True,
                temperature=self._kwargs.get('temperature', 0.5),
                top_p=self._kwargs.get('top_p', 1),
            )
        return self._llm

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
```

**调用方变化**
```python
# 原来
from ai.LoadLLM import load_model
llm = load_model()

# 改后
from ai.LLMService import LLMService
llm = LLMService.get_instance().get()      # 生产用单例
# 测试时可直接 new 一个隔离实例：
llm = LLMService(api_key="fake-key", model="test-model").get()
```

---

### 示例 2：每函数重复读配置 → 配置注入类（`common/JWTUtil.py` → `JWTManager`）

**当前（函数式）**
```python
# common/JWTUtil.py
from jose import JWTError, jwt
import os
os.getenv  # 每个函数都读一遍 secret/expire

def create_access_token(data: dict):
    ...

def verify_token(token):
    ...
```

**改后（配置注入类）**
```python
from jose import JWTError, jwt
from datetime import datetime, timedelta, timezone
import secrets

class JWTManager:
    """JWT 管理：密钥与过期时间在构造时注入，方法化管理。"""

    def __init__(self, secret_key: str, expire_minutes: int, algorithm: str = "HS256"):
        self._secret = secret_key
        self._expire_minutes = expire_minutes
        self._algorithm = algorithm

    def create_access_token(self, data: dict) -> str:
        copy_data = data.copy()
        now = datetime.now(timezone.utc)
        copy_data.update({
            "exp": now + timedelta(minutes=self._expire_minutes),
            "iat": now,
            "user_id": data.get("user_id"),
            "username": data.get("username"),
            "role_name": data.get("role_name"),
            "jti": secrets.token_hex(8),
        })
        return jwt.encode(copy_data, self._secret, algorithm=self._algorithm)

    def verify_token(self, token):
        # ... 逻辑不变，secret 用 self._secret
        ...
```
**效果**：配置读一次；未来换密钥/过期时间在构造处传参，测试时可注入假密钥。

---

### 示例 3：游离业务函数 + 裸 dict → Service 类 + Response 类（`user/service/UserService.py`）

**先做统一响应类**
```python
# common/ApiResponse.py
from dataclasses import dataclass

@dataclass
class ApiResponse:
    code: int
    msg: str
    data: object = None

    @staticmethod
    def ok(data=None, msg="成功") -> "ApiResponse":
        return ApiResponse(code=200, msg=msg, data=data)

    @staticmethod
    def fail(msg, code=400, data=None) -> "ApiResponse":
        return ApiResponse(code=code, msg=msg, data=data)
```

**再做 Service 类**
```python
# user/service/UserService.py
from user.dao import UsersDao
from common.ApiResponse import ApiResponse

class UserService:
    """用户业务服务：方法化 + 统一响应。"""

    def __init__(self, redis_client, email_sender=None):
        # 依赖注入：redis、邮件发送器可替换，便于测试
        self._redis = redis_client
        self._email_sender = email_sender

    def get_profile(self, email):
        profile = UsersDao.get_user_profile(email)
        if profile is None:
            return ApiResponse.fail("用户不存在")
        return ApiResponse.ok(profile, "查询成功")

    def register_user(self, entity):
        if UsersDao.check_email(entity.email):
            return ApiResponse.fail("账号已注册")
        return UsersDao.add_user(entity.username, entity.email, entity.password)
```

**Controller 层轻量接入**
```python
# user/controller/UserController.py
from fastapi import APIRouter, Request
from user.service.UserService import UserService

users_router = APIRouter()

@users_router.get('/profile', summary='查询资料')
def get_profile(email: str, request: Request):
    svc: UserService = request.app.state.user_service   # 依赖注入
    return svc.get_profile(email)
```

---

## 四、结尾：一套“类化程度速查”

改之前问自己三个问题，答案决定“类不类”：
1. **它有没有状态？**（有没有 `global`、模块级 `= None`、要 hold 住的东西）→ 有，就类。
2. **它是不是一个资源/连接/模型的“管家”？** → 是，就类（单例或池）。
3. **它是不是一组功能上应当绑定在一起的函数？** → 是，就类（方法化）。

只要没有命中，就**不用硬改成类**——函数式在合适的地方（纯算法、路由、DAO 简单查询）完全够用且更简洁。**面向对象不是“全部都要类”，而是“让有状态、要复用、要测试的东西长成类”。**
