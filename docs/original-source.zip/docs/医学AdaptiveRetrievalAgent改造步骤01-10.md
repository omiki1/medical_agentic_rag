# 医学 Adaptive Retrieval Agent 改造详细步骤（01-10）

> 基于实际项目代码比对后的改造方案
> 项目：`C:\workspace\medical_disease_db`
> 目标：把现有 "Agent 查图谱 + RAG 闲置" 升级为 "Agent 编排 + 多路检索 + 证据融合" 的完整链路

---

## 目录

- [第 1 部分：现状盘点与问题确认](#第-1-部分现状盘点与问题确认)
- [第 2 部分：设计目标架构与数据流](#第-2-部分设计目标架构与数据流)
- [第 3 部分：统一 Evidence 数据模型](#第-3-部分统一-evidence-数据模型)
- [第 4 部分：封装 HybridRetriever（基线检索）](#第-4-部分封装-hybridretriever基线检索)
- [第 5 部分：升级 HydeRetriever（增强检索）](#第-5-部分升级-hyderetriever增强检索)
- [第 6 部分：新增 GraphRetriever（图谱检索）](#第-6-部分新增-graphretriever图谱检索)
- [第 7 部分：实现 EvidenceFusion（证据融合）](#第-7-部分实现-evidencefusion证据融合)
- [第 8 部分：重构 Agent（Router + Tools + State）](#第-8-部分重构-agentrouter--tools--state)
- [第 9 部分：ChatService 瘦身与整链路打通](#第-9-部分-chatservice-瘦身与整链路打通)
- [第 10 部分：评测体系与验收](#第-10-部分评测体系与验收)

---

## 第 1 部分：现状盘点与问题确认

### 1.1 实际项目结构（已验证）

```
backend/
├── agent/
│   ├── AgentToolbox.py      # query_cql + get_weather + random_character
│   └── build_agent.py       # Neo4j 连接 + system_prompt + create_agent
├── ai/
│   ├── IntentionService.py  # 医学意图识别（提示词已是医学，但返回 is_security）
│   ├── LLMService.py        # GLM/DeepSeek LLM
│   └── VectorStoreService.py# Chroma 单例
├── rag/
│   ├── BM25Retriever.py     # BM25 关键词检索
│   ├── VectorRetriever.py   # 向量检索
│   ├── HydeUtil.py          # HyDE 假设文档
│   ├── RRFUtil.py           # RRF 融合
│   ├── RerankerUtil.py      # Reranker（未接入）
│   └── SummaryHistory.py    # 历史摘要
├── chat/service/ChatService.py  # 只有 6 行，直接调 Agent
└── main.py                  # FastAPI 入口
```

### 1.2 核心问题（已确认）

| # | 问题 | 证据 |
|---|------|------|
| 1 | **RAG 检索模块完全闲置** | ChatService 只调 `GetAgent().run()`，检索模块从未被调用 |
| 2 | **Agent 只有图谱/天气/动漫** | AgentToolbox 无检索工具 |
| 3 | **IntentionService 有 bug** | 提示词输出 `is_medical`，但代码读 `is_security` |
| 4 | **数据错位** | Chroma 存的是 CVE 漏洞数据（非医学），需换医学数据 |
| 5 | **Reranker 未接入** | RerankerUtil 只定义了函数，无调用 |

### 1.3 改造原则

- **保留**：auth、user、chat、common、frontend、MySQL/Redis 基础设施（70%）
- **改造**：rag/、agent/、ai/IntentionService、create_data/（30%）
- **目标**：`medical_agent.run(query)` 内部完成 意图分析 → 多路检索 → 证据融合 → 回答

---

## 第 2 部分：设计目标架构与数据流

### 2.1 目标架构

```
用户提问
   │
   ▼
ChatService（薄）
   │
   ▼
MedicalAgent.run(query)
   │
   ├── ① QueryAnalyzer（意图+实体+路由计划）
   │
   ├── ② HybridRetriever（永远运行）
   │      ├── VectorRetriever → Chroma
   │      └── BM25Retriever → BM25 索引
   │      └── RRF 融合 → 基线结果
   │
   ├── ③ 条件分支（由路由计划决定）
   │      ├── HyDERetriever（模糊/低置信时）
   │      └── GraphRetriever（关系型问题时）
   │
   ├── ④ EvidenceFusion（多路证据融合）
   │
   ├── ⑤ Reranker（精排）
   │
   ├── ⑥ ContextBuilder（组装 prompt）
   │
   └── ⑦ LLM 生成回答（带证据引用）
```

### 2.2 数据流

```
query
  → QueryAnalyzer.analyze() → RetrievalPlan
  → HybridRetriever.retrieve() → list[Evidence]
  → (可选) HyDERetriever.retrieve() → list[Evidence]
  → (可选) GraphRetriever.retrieve() → list[Evidence]
  → EvidenceFusion.fuse() → list[Evidence]
  → Reranker.rerank() → list[Evidence]
  → ContextBuilder.build() → prompt
  → LLMService.invoke() → answer
```

### 2.3 关键设计决策

| 决策 | 理由 |
|------|------|
| Hybrid 永远运行 | 基线检索最可靠，Agent 只决定是否扩展 |
| HyDE/Graph 条件触发 | 省 token、省时间，只在需要时扩展 |
| 统一 Evidence | 多路结果格式一致，融合/重排/引用才可能 |
| Agent 不直接写 Cypher | 安全、稳定、可测试 |

---

## 第 3 部分：统一 Evidence 数据模型

### 3.1 为什么需要

当前各检索器返回格式不一：
- VectorRetriever → `Document`
- BM25Retriever → `Document`
- Neo4j → `dict`
- HyDE → 只有假设文档（无真实文档）

统一后：**所有检索器返回 `list[Evidence]`**

### 3.2 代码示例

新建 `backend/rag/model/Evidence.py`：

```python
from pydantic import BaseModel
from typing import Optional, Any


class Evidence(BaseModel):
    """统一检索证据模型"""

    # 核心字段
    text: str                                # 证据文本
    source: str = "unknown"                  # 来源标识（文档名/图谱/百科）
    source_type: str = "document"            # document | graph | knowledge

    # 检索元信息
    retrieval_method: str = "unknown"        # dense | bm25 | hyde | graph
    score: Optional[float] = None            # 检索得分
    rank: Optional[int] = None               # 融合后排名

    # 溯源字段
    doc_id: Optional[str] = None             # 文档 ID
    title: Optional[str] = None              # 标题
    metadata: dict = {}                      # 额外元数据

    # 图谱专用
    graph_path: Optional[list] = None        # 图谱路径（如 [糖尿病, -COMMON_DRUG->, 二甲双胍]）

    def __str__(self):
        return f"[{self.retrieval_method}] {self.text[:50]}..."
```

### 3.3 使用方式

```python
# 向量检索结果
ev = Evidence(
    text="糖尿病的典型症状包括多饮多尿...",
    source="内科学",
    retrieval_method="dense",
    doc_id="medical_001",
)

# 图谱检索结果
ev2 = Evidence(
    text="糖尿病 -COMMON_DRUG-> 二甲双胍",
    source="OpenCMKG",
    source_type="graph",
    retrieval_method="graph",
    graph_path=["糖尿病", "COMMON_DRUG", "二甲双胍"],
)
```

---

## 第 4 部分：封装 HybridRetriever（基线检索）

### 4.1 为什么封装

现在 BM25 + 向量 + RRF 是散落的工具函数，调用方（未来是 Agent）需要知道太多细节。封装后外部只调 `hybrid_retriever.retrieve(query)`。

### 4.2 代码示例

新建 `backend/rag/retriever/HybridRetriever.py`：

```python
from typing import Optional
from rag.model.Evidence import Evidence
from rag.VectorRetriever import search as vector_search
from rag.BM25Retriever import get_bm25_index, search_bm25
from rag.RRFUtil import rrf
from ai.VectorStoreService import VectorStoreService


class HybridRetriever:
    """混合检索：向量 + BM25 + RRF 融合（基线检索器）"""

    def __init__(self, top_k: int = 20):
        self.top_k = top_k
        self._bm25 = None
        self._docs = None

    def _ensure_bm25(self):
        """懒加载 BM25 索引"""
        if self._bm25 is None:
            vector_db = VectorStoreService.get_chroma()
            self._docs, self._bm25 = get_bm25_index(vector_db)
        return self._docs, self._bm25

    def retrieve(self, query: str, top_k: Optional[int] = None) -> list[Evidence]:
        """执行混合检索，返回统一 Evidence 列表"""
        k = top_k or self.top_k

        # 1. 向量检索
        vector_results = vector_search(query, k=k)

        # 2. BM25 检索
        docs, bm25 = self._ensure_bm25()
        bm25_results = search_bm25(bm25, query, docs, k=k)

        # 3. RRF 融合
        merged = rrf(vector_results, vector_results, bm25_results)

        # 4. 转统一 Evidence
        evidences = []
        for rank, doc in enumerate(merged[:k], start=1):
            evidences.append(Evidence(
                text=doc.page_content,
                source=doc.metadata.get("source", "unknown") if doc.metadata else "unknown",
                retrieval_method="hybrid",
                rank=rank,
                doc_id=getattr(doc, "id", None),
                metadata=doc.metadata or {},
            ))
        return evidences
```

### 4.3 外部调用

```python
hybrid = HybridRetriever(top_k=20)
evidences = hybrid.retrieve("糖尿病有哪些症状")
```

---

## 第 5 部分：升级 HydeRetriever（增强检索）

### 5.1 为什么改造

现有 `HydeUtil.py` 只是生成假设文档的函数，且提示词是"网络安全"语境。升级为：
1. 提示词医学化
2. 封装成 Retriever 类（生成假设文档 → 向量检索 → 返回真实文档 Evidence）

### 5.2 代码示例

新建 `backend/rag/retriever/HydeRetriever.py`（并更新 HydeUtil 提示词）：

```python
from rag.model.Evidence import Evidence
from rag.HydeUtil import build_hyde_query
from rag.VectorRetriever import search as vector_search
from rag.HydeTrigger import should_use_hyde  # 之前方案中的触发判断


class HydeRetriever:
    """HyDE 增强检索：先用 LLM 生成假设文档，再向量检索真实文档"""

    def __init__(self, top_k: int = 10):
        self.top_k = top_k

    def retrieve(self, query: str) -> list[Evidence]:
        """执行 HyDE 检索，返回真实文档的 Evidence"""

        # 1. 判断是否需要 HyDE
        if not should_use_hyde(query):
            return []

        # 2. 生成假设文档（只用于检索，不直接作为证据）
        hyde_doc = build_hyde_query(query)

        # 3. 用假设文档做向量检索，返回真实文档
        results = vector_search(hyde_doc, k=self.top_k)

        # 4. 转 Evidence（注意：retrieval_method=hyde，但 text 是真实文档）
        evidences = []
        for rank, doc in enumerate(results, start=1):
            evidences.append(Evidence(
                text=doc.page_content,
                source=doc.metadata.get("source", "unknown") if doc.metadata else "unknown",
                retrieval_method="hyde",
                rank=rank,
                doc_id=getattr(doc, "id", None),
                metadata=doc.metadata or {},
            ))
        return evidences
```

### 5.3 关键点

- **HyDE 文档不直接作为 Evidence**，只是"检索用的查询"
- **Evidence.text 必须是真实文档**（否则就是幻觉）
- 触发条件：`should_use_hyde(query)`（长/模糊问题）或 `retrieval_confidence < threshold`

---

## 第 6 部分：新增 GraphRetriever（图谱检索）

### 6.1 为什么封装

现在 `AgentToolbox.query_cql` 让 LLM 直接生成 Cypher 执行，不稳定、不安全。封装为 `GraphRetriever`：
- 输入：自然语言 + 实体 + 关系类型
- 输出：统一 Evidence（含 graph_path）

### 6.2 代码示例

新建 `backend/rag/retriever/GraphRetriever.py`：

```python
from typing import Optional
from langchain_neo4j import Neo4jGraph
from rag.model.Evidence import Evidence


class GraphRetriever:
    """图谱检索：实体 → Cypher → Neo4j → Evidence"""

    def __init__(self, url: str = "bolt://localhost:7687",
                 username: str = "neo4j",
                 password: str = "12345678",
                 database: str = "abc"):
        self.graph = Neo4jGraph(
            url=url, username=username, password=password, database=database,
        )

    def retrieve(self, query: str, entities: list[str],
                 relation_types: Optional[list[str]] = None,
                 max_results: int = 10) -> list[Evidence]:
        """查询图谱中与实体相关的信息，返回 Evidence"""

        evidences = []
        for entity in entities:
            # 查询该实体的所有关系（可限制关系类型）
            cypher = self._build_cypher(entity, relation_types, max_results)
            try:
                rows = self.graph.query(cypher)
            except Exception as e:
                print(f"[GraphRetriever] 查询失败: {e}")
                continue

            for row in rows:
                # row 形如 {"s": ..., "r": ..., "t": ...}
                s = row.get("s", "")
                r = row.get("r", "")
                t = row.get("t", "")
                evidences.append(Evidence(
                    text=f"{s} -{r}-> {t}",
                    source="OpenCMKG",
                    source_type="graph",
                    retrieval_method="graph",
                    graph_path=[s, r, t],
                ))
        return evidences[:max_results]

    def _build_cypher(self, entity: str,
                      relation_types: Optional[list[str]],
                      limit: int) -> str:
        """构造 Cypher：查实体的所有关系"""
        # 安全：实体名参数化，关系类型白名单
        rel_clause = ""
        if relation_types:
            rels = ", ".join(f":{r}" for r in relation_types)
            rel_clause = f"[r:{rels}]"
        else:
            rel_clause = "[r]"

        return f"""
        MATCH (s {{name: $entity}})-{rel_clause}->(t)
        RETURN s.name AS s, type(r) AS r, t.name AS t
        LIMIT {limit}
        """, {"entity": entity}
```

> 注意：实际 Neo4jGraph.query 的参数化写法需按 langchain_neo4j 版本调整；核心思想是**不让 LLM 直接生成 Cypher，而是由代码构造**。

### 6.3 与 query_cql 的关系

- `query_cql`：保留给 Agent 的"自由查询"工具（演示用）
- `GraphRetriever`：正式链路使用（安全、结构化）

---

## 第 7 部分：实现 EvidenceFusion（证据融合）

### 7.1 为什么需要

现在 RRF 只处理向量+BM25。升级后需要融合：Hybrid + HyDE + Graph 三路证据，做去重、归一化、加权融合。

### 7.2 代码示例

新建 `backend/rag/fusion/EvidenceFusion.py`：

```python
from rag.model.Evidence import Evidence


class EvidenceFusion:
    """多路证据融合：去重 + 加权 + TopN"""

    # 各路权重（可按实验调整）
    WEIGHTS = {
        "hybrid": 1.0,
        "hyde": 0.7,
        "graph": 0.9,
    }

    def fuse(self, *evidence_lists: list[Evidence], top_n: int = 15) -> list[Evidence]:
        """融合多路 Evidence"""

        # 1. 去重（按 text 去重，保留权重最高的一路）
        seen = {}
        for evidences in evidence_lists:
            for ev in evidences:
                key = ev.text.strip()
                weight = self.WEIGHTS.get(ev.retrieval_method, 0.5)
                if key not in seen or weight > self.WEIGHTS.get(seen[key].retrieval_method, 0):
                    seen[key] = ev

        # 2. 按权重 + 原排名排序
        ranked = sorted(
            seen.values(),
            key=lambda e: (self.WEIGHTS.get(e.retrieval_method, 0.5), - (e.rank or 99)),
            reverse=True,
        )

        # 3. 重新编号
        for i, ev in enumerate(ranked[:top_n], start=1):
            ev.rank = i

        return ranked[:top_n]
```

### 7.3 使用

```python
fusion = EvidenceFusion()
final_evidence = fusion.fuse(
    hybrid_evidences,
    hyde_evidences,
    graph_evidences,
    top_n=15,
)
```

---

## 第 8 部分：重构 Agent（Router + Tools + State）

### 8.1 设计思路

放弃"万能工具箱"（天气/动漫），改为**医学检索专用 Agent**：

```
MedicalAgent.run(query)
  → QueryAnalyzer.analyze() → RetrievalPlan
  → 执行计划（Hybrid 必跑 + HyDE/Graph 按需）
  → 融合 → 重排 → 生成
```

### 8.2 代码示例

新建 `backend/agent/AgentRouter.py`：

```python
from pydantic import BaseModel
from ai.LLMService import LLMService
import json


class RetrievalPlan(BaseModel):
    """检索计划：Agent 的决策结果"""
    use_hyde: bool = False
    use_graph: bool = False
    entities: list[str] = []
    query_type: str = "fact"   # fact | relation | symptom | mixed
    reason: str = ""


class AgentRouter:
    """路由决策：判断是否需要 HyDE / Graph"""

    PROMPT = """你是医学检索路由。根据用户问题，输出 JSON 决策：
{{
  "use_hyde": true/false,      # 模糊/描述性问题→true；明确短查询→false
  "use_graph": true/false,     # 关系型问题（症状/药物/科室/饮食关系）→true
  "entities": ["疾病/药物名"],  # 提取的医学实体
  "query_type": "fact|relation|symptom|mixed",
  "reason": "一句话原因"
}}
只输出 JSON，不要其他文字。"""

    @classmethod
    def plan(cls, question: str) -> RetrievalPlan:
        llm = LLMService.get_glm()
        rs = llm.invoke([
            {"role": "system", "content": cls.PROMPT},
            {"role": "user", "content": question},
        ])
        try:
            data = json.loads(rs.content)
            return RetrievalPlan(**data)
        except Exception:
            # 解析失败时保守默认：只用 Hybrid
            return RetrievalPlan()
```

新建 `backend/agent/MedicalAgent.py`：

```python
from agent.AgentRouter import AgentRouter
from rag.retriever.HybridRetriever import HybridRetriever
from rag.retriever.HydeRetriever import HydeRetriever
from rag.retriever.GraphRetriever import GraphRetriever
from rag.fusion.EvidenceFusion import EvidenceFusion
from rag.reranker.RerankerUtil import reranker_func  # 需封装
from ai.LLMService import LLMService


class MedicalAgent:
    """医学自适应检索 Agent"""

    def __init__(self):
        self.router = AgentRouter()
        self.hybrid = HybridRetriever()
        self.hyde = HydeRetriever()
        self.graph = GraphRetriever()
        self.fusion = EvidenceFusion()

    def run(self, query: str):
        """完整链路：路由 → 检索 → 融合 → 重排 → 生成"""

        # 1. 路由决策
        plan = self.router.plan(query)
        print(f"[Agent] plan={plan.model_dump()}")

        # 2. Hybrid 永远运行
        hybrid_evs = self.hybrid.retrieve(query)

        # 3. 条件分支
        hyde_evs = self.hyde.retrieve(query) if plan.use_hyde else []
        graph_evs = self.graph.retrieve(query, plan.entities) if plan.use_graph else []

        # 4. 融合
        final_evs = self.fusion.fuse(hybrid_evs, hyde_evs, graph_evs, top_n=15)

        # 5. 重排（可选）
        # final_evs = reranker_func(final_evs)

        # 6. 构建上下文 + 生成
        context = "\n\n".join(f"[{i}] {e.text}" for i, e in enumerate(final_evs, 1))
        prompt = f"""你是严谨的医学知识助手。请基于以下检索证据回答用户问题。
证据不足时如实说明，不要编造。

【检索证据】
{context}

【用户问题】
{query}

【回答要求】
1. 优先引用证据作答
2. 回答末尾标注引用编号，如 [1][3]
3. 涉及用药/治疗时提示"请遵医嘱"
"""

        llm = LLMService.get_glm()
        rs = llm.invoke([
            {"role": "system", "content": "你是医学知识助手，回答严谨克制。"},
            {"role": "user", "content": prompt},
        ])
        yield rs.content
```

---

## 第 9 部分：ChatService 瘦身与整链路打通

### 9.1 目标

ChatService 只做三件事：调 Agent、流式返回、保存历史。**不知道任何检索细节**。

### 9.2 修改 ChatService.py

```python
from agent.MedicalAgent import MedicalAgent


def chat(question: str, historyId: int, username):
    """聊天入口：调 Agent，流式返回"""
    agent = MedicalAgent()
    for chunk in agent.run(question):
        yield chunk


if __name__ == '__main__':
    pass
```

### 9.3 修改 IntentionService bug

```python
# 原代码（bug）：提示词输出 is_medical，但代码读 is_security
return {
    "is_security": bool(result.get("is_security", True)),  # ❌
}

# 修正
return {
    "is_medical": bool(result.get("is_medical", False)),   # ✅
    "confidence": result.get("confidence", "low"),
    "category": result.get("category", ""),
}
```

### 9.4 整链路验证

```bash
# 启动后端
cd C:\workspace\medical_disease_db\backend
C:\path\to\python.exe main.py

# 测试三种问题
# 1. 关系型："糖尿病有哪些症状" → Hybrid + Graph
# 2. 解释型："糖尿病的病因是什么" → Hybrid（+HyDE 如果模糊）
# 3. 复合型："糖尿病饮食注意什么" → Hybrid + Graph + HyDE
```

---

## 第 10 部分：评测体系与验收

### 10.1 为什么需要评测

没有评测，无法证明"加了 Graph/HyDE 到底有没有用"。答辩时数据说话。

### 10.2 评测数据

新建 `backend/evaluation/datasets/`：

**retrieval_test.jsonl**（检索质量）
```json
{"query": "糖尿病有哪些典型症状？", "relevant_doc_ids": ["medical_001", "medical_328"]}
{"query": "高血压患者不能吃什么？", "relevant_doc_ids": ["medical_052"]}
```

**router_test.jsonl**（路由正确性）
```json
{"query": "糖尿病有哪些典型症状？", "expected_route": {"hyde": false, "graph": true}}
{"query": "最近总是喝很多水还一直变瘦", "expected_route": {"hyde": true, "graph": false}}
```

### 10.3 评测代码

新建 `backend/evaluation/RetrievalEvaluator.py`：

```python
def recall_at_k(retrieved: list[str], relevant: list[str], k: int) -> float:
    """Recall@K：检索到的相关文档数 / 总相关文档数"""
    top_k = set(retrieved[:k])
    relevant_set = set(relevant)
    if not relevant_set:
        return 0.0
    return len(top_k & relevant_set) / len(relevant_set)


def mrr(retrieved: list[str], relevant: list[str]) -> float:
    """MRR：第一个相关文档排名的倒数"""
    relevant_set = set(relevant)
    for i, doc_id in enumerate(retrieved, start=1):
        if doc_id in relevant_set:
            return 1.0 / i
    return 0.0
```

### 10.4 消融实验（Ablation）

| 系统 | 说明 |
|------|------|
| A | Dense（纯向量）|
| B | Dense + BM25 |
| C | B + RRF |
| D | C + Reranker |
| E | D + HyDE |
| F | D + Graph |
| G | **自适应 Agent（完整）** |

> 答辩核心：展示 G 比 A 的 Recall@5 / MRR / 回答准确率提升，用数据证明每层改造的价值。

### 10.5 验收清单

- [ ] 医学数据灌入独立 Chroma（不再是 CVE 数据）
- [ ] HybridRetriever 返回统一 Evidence
- [ ] HyDE 触发条件生效（模糊问题才启用）
- [ ] GraphRetriever 返回图谱关系 Evidence
- [ ] EvidenceFusion 融合三路去重
- [ ] MedicalAgent 完整链路跑通
- [ ] IntentionService bug 修复
- [ ] 消融实验数据产出
- [ ] 前端展示"参考来源 + 检索详情"

---

## 附：实施顺序建议

```
第 1 步：医学数据入库（Chroma + BM25 换成医学文档）
第 2 步：Evidence 模型（第 3 部分）
第 3 步：HybridRetriever 封装（第 4 部分）
第 4 步：HydeRetriever 升级（第 5 部分）
第 5 步：GraphRetriever 新增（第 6 部分）
第 6 步：EvidenceFusion（第 7 部分）
第 7 步：Agent 重构（第 8 部分）
第 8 步：ChatService 打通（第 9 部分）
第 9 步：评测体系（第 10 部分）
第 10 步：前端展示增强（可选）
```
