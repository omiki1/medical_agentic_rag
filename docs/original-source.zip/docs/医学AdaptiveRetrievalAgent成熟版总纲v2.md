# 医学 Adaptive Retrieval Agent —— 成熟版实施总纲（01-10）

> 版本：v2.0（在 v1.0 基础上，融入数据质量验证结论、架构决策、风险预案与演进路线）
> 项目根：`C:\workspace\medical_disease_db`
> 目标：把 "Agent 查图谱 + RAG 闲置" 升级为 "Agent 编排 + 多路检索 + 证据融合 + 可评测" 的完整医学检索系统

---

## 前置：数据验证结论（本总纲的事实基础）

以下数据已实测验证（2026-09）：

| 验证项 | 结果 | 意义 |
|---|---|---|
| 医学数据源 | `stu-neoj4/.../medical.json` 8,808 条 | 现成可用，不用找数据 |
| 字段完整性 | name/desc/category 100%；symptom 99.5%；cause 99.8% | 质量高，可直接用 |
| 重名疾病 | 仅 1 个 | 几乎无噪声 |
| desc 长度 | 中位 164 字，p75 235 字 | 适合直接切块 |
| JSON ↔ Neo4j 匹配 | **100%（3000 样本全对上）** | 文档与图谱天然同源！ |
| 图谱关系 | 10 种（症状/药物/科室/饮食/检查…）| 关系丰富 |

**核心结论**：`medical.json` 与 Neo4j 图谱**同源同构**（同一疾病体系），这意味着：
- 图谱节点 ↔ JSON 文档可**互相反查**（图谱找到实体 → JSON 找到详细文档）
- 这是 GraphRAG 最理想的数据基础 —— 双引擎天然对齐

---

## 目录

- [第 1 部分：架构总览与设计决策](#第-1-部分架构总览与设计决策)
- [第 2 部分：数据工程（医学语料入库）](#第-2-部分数据工程医学语料入库)
- [第 3 部分：统一 Evidence 数据模型](#第-3-部分统一-evidence-数据模型)
- [第 4 部分：HybridRetriever（基线检索）](#第-4-部分-hybridretriever基线检索)
- [第 5 部分：HydeRetriever（语义增强）](#第-5-部分-hyderetriever语义增强)
- [第 6 部分：GraphRetriever（关系增强）](#第-6-部分-graphretriever关系增强)
- [第 7 部分：EvidenceFusion（证据融合）](#第-7-部分-evidencefusion证据融合)
- [第 8 部分：RetrievalRouter + MedicalAgent](#第-8-部分-retrievalrouter--medicalagent)
- [第 9 部分：接入层与前端](#第-9-部分接入层与前端)
- [第 10 部分：评测体系与演进路线](#第-10-部分评测体系与演进路线)

---

## 第 1 部分：架构总览与设计决策

### 1.1 目标架构

```
用户提问
   │
   ▼
ChatService（薄：历史 + 调 Agent + 保存 + SSE）
   │
   ▼
MedicalAgent.run(query)
   │
   ├─① QueryAnalyzer（意图 + 实体 + 路由计划）
   │
   ├─② HybridRetriever ── 永远运行（基线）
   │     ├─ VectorRetriever → Chroma（Dense）
   │     ├─ BM25Retriever → BM25（Sparse）
   │     └─ RRF 融合
   │
   ├─③ 条件分支（由 RetrievalPlan 决定）
   │     ├─ HyDERetriever（模糊/低置信时）
   │     └─ GraphRetriever（关系型问题时）
   │
   ├─④ EvidenceFusion（多路融合去重）
   │
   ├─⑤ Reranker（4070 GPU 精排）
   │
   ├─⑥ ContextBuilder（组装 prompt）
   │
   └─⑦ LLM → Answer + Evidence Citation
```

### 1.2 关键设计决策（为什么这么做）

| 决策 | 理由 |
|---|---|
| **Hybrid 永远运行** | 基线检索最可靠，Agent 只决定是否扩展，避免漏掉文本证据 |
| **HyDE/Graph 条件触发** | 省 token、省延迟，只在需要时扩展 |
| **Agent 不直接写 Cypher** | 安全、稳定、可测试；query_cql 降级为 GraphRetriever 底层 |
| **统一 Evidence** | 多路结果格式一致，融合/重排/引用/前端展示才可能 |
| **医学工具独立** | 去掉天气/动漫，Agent 工具空间纯净，路由更稳定 |
| **多模态降为 Phase 2** | 先建 Adaptive Retrieval Core，再扩展图片能力 |

### 1.3 保留 vs 改造

| 保留（70%）| 改造（30%）|
|---|---|
| auth / user / chat MVC / common | rag/（封装+新增）|
| MySQL / Redis / JWT | agent/（重构）|
| VectorStoreService / LLMService | ai/IntentionService（修 bug + 升级）|
| frontend（Vue3 + SSE）| create_data/（医学灌库）|
| Neo4j 图谱（数据不动）| 新增 evaluation/ |

---

## 第 2 部分：数据工程（医学语料入库）

### 2.1 数据源确认

- **主数据**：`C:\workspace\stu-neoj4\create_data\create_data\datasets\medical.json`
  - 8,808 条疾病，JSONL 格式
  - 字段：name/desc/category/prevent/cause/symptom/acompany/cure_department/cure_way/cure_lasttime/cured_prob/yibao_status/get_prob/get_way/easy_get
- **图谱数据**：Neo4j `abc` 库（8,807 Disease 节点，与 JSON 100% 匹配）

### 2.2 文档生成策略（为什么这样拼）

每条疾病生成**一个结构化文档**（不是原文，而是模板化重组）：

```
【疾病名称】肺泡蛋白质沉积症
【疾病描述】肺泡蛋白质沉积症(简称PAP)，又称Rosen-Castle-man-Liebow综合征...
【病因】...
【症状】...
【预防】...
【并发症】...
【就诊科室】呼吸内科
【治疗方法】...
【治疗时长】...
【治愈概率】...
【医保】...
```

**理由**：
1. 字段模板化 → 检索时"问症状"命中【症状】段、"问科室"命中【科室】段
2. 与图谱关系类型一一对应 → 图谱/文档可互相反查
3. 每条 300-500 字 → 一个 chunk，无需再切分

### 2.3 入库流程

```
medical.json（8,808 条）
   │
   ├─→ 生成结构化文档（8,808 篇）
   │     ├─→ Chroma（独立 collection: medical_kb）
   │     └─→ BM25 索引（基于同源文档）
   │
   └─→ Neo4j（已就绪，不动）
```

**独立存储（必须）**：
```
CHROMA_PATH = C:/workspace/medical_disease_db/backend/chroma_medical
COLLECTION_NAME = medical_kb
```

**注意**：`.env` 里的 `DATA_ROOT` 指向 rag_system_v2 的 cve 数据 —— 医学版要改指向 medical.json。

### 2.4 数据质量结论（已实测）

- 缺失率极低：核心字段 99%+ 完整
- desc 中位 164 字 → 文档总长可控
- 仅 1 个重名 → 无需清洗
- JSON ↔ 图谱 100% 对齐 → 双引擎同源

### 2.5 风险与预案

| 风险 | 预案 |
|---|---|
| Chroma 旧数据残留（CVE）| 用独立 collection/path，互不干扰 |
| Embedding 模型加载失败 | 确认 `C:/model/paraphrase-multilingual-MiniLM-L12-v2` 存在 |
| 文档过长 | 已按字段模板控制长度；如超限再切块 |
| GPU 显存不足 | Reranker 与 Embedding 不同时加载大模型 |

---

## 第 3 部分：统一 Evidence 数据模型

### 3.1 为什么必须统一

当前各检索器返回：Document（向量/BM25）、dict（图谱）、str（HyDE）。统一后一切皆 `Evidence`。

### 3.2 设计（含多模态预留）

新建 `backend/rag/entity/Evidence.py`：

```python
from pydantic import BaseModel
from typing import Optional, Any


class Evidence(BaseModel):
    """统一检索证据（预留多模态字段）"""

    # 核心
    text: str                              # 证据文本
    source: str = "unknown"                # 来源（文档名/图谱/百科）
    source_type: str = "text"              # text | graph | image

    # 检索信息
    retrieval_method: str = "unknown"      # dense | bm25 | hybrid | hyde | graph | multimodal
    score: Optional[float] = None
    rank: Optional[int] = None

    # 溯源
    doc_id: Optional[str] = None
    title: Optional[str] = None
    metadata: dict = {}

    # 图谱/多模态
    graph_path: Optional[list] = None      # [糖尿病, -DRUG->, 二甲双胍]
    image_path: Optional[str] = None       # 多模态阶段使用
```

### 3.3 各路返回示例

```python
# Hybrid
Evidence(text="糖尿病的典型症状包括...", source="medical_book", retrieval_method="hybrid")
# HyDE（注意：text 是真实文档，不是假设文档）
Evidence(text="糖尿病是一种代谢性疾病...", source="encyclopedia", retrieval_method="hyde")
# Graph
Evidence(text="糖尿病 -COMMON_DRUG-> 二甲双胍", source="OpenCMKG",
         source_type="graph", retrieval_method="graph",
         graph_path=["糖尿病", "COMMON_DRUG", "二甲双胍"])
# 未来图片
Evidence(text="肺部CT影像显示...", source="image_kb", source_type="image",
         retrieval_method="multimodal", image_path="ct_001.jpg")
```

---

## 第 4 部分：HybridRetriever（基线检索）

### 4.1 职责

封装 Vector + BM25 + RRF，对外只暴露 `retrieve(query) -> list[Evidence]`。

### 4.2 关键设计

- **懒加载 BM25**：首次调用才构建索引（8,808 篇很快）
- **RRF 权重**：向量与 BM25 权重可调
- **返回 Evidence**：统一格式

### 4.3 伪代码（示意，实施时再写完整版）

```python
class HybridRetriever:
    def retrieve(self, query, top_k=20) -> list[Evidence]:
        vector_results = VectorRetriever.search(query, k=top_k)
        bm25_results = BM25Retriever.search_bm25(query, docs, k=top_k)
        merged = RRFUtil.rrf(vector_results, vector_results, bm25_results)
        return [to_evidence(doc, "hybrid") for doc in merged[:top_k]]
```

### 4.4 验证方式

```python
hybrid = HybridRetriever()
evs = hybrid.retrieve("糖尿病有哪些症状")
print(len(evs), evs[0].text[:50])
```

---

## 第 5 部分：HydeRetriever（语义增强）

### 5.1 职责

模糊/描述性问题时，先用 LLM 生成假设文档，再向量检索**真实文档**。

### 5.2 关键设计

- **HyDE 文档只用于检索，不作为证据**（防幻觉）
- **触发条件**：`should_use_hyde(query)`（长/模糊/含"如何/原因/区别"）或 **低检索置信度**（top1 score < 阈值）
- **提示词医学化**：现有 HydeUtil 提示词是网络安全语境，需改为医学

### 5.3 触发判断（RetrievalPlan 的一部分）

```
use_hyde = (query 模糊) or (hybrid top1 score < 0.35)
```

### 5.4 伪代码

```python
class HydeRetriever:
    def retrieve(self, query) -> list[Evidence]:
        if not should_use_hyde(query):
            return []
        hyde_doc = HydeUtil.build_hyde_query(query)   # LLM 生成假设文档
        results = VectorRetriever.search(hyde_doc, k=10)
        return [to_evidence(doc, "hyde") for doc in results]   # 真实文档
```

---

## 第 6 部分：GraphRetriever（关系增强）

### 6.1 职责

关系型问题时，用**实体 + 关系类型**查 Neo4j，返回结构化关系 Evidence。

### 6.2 关键设计

- **不让 LLM 直接写 Cypher**：由代码构造（实体参数化 + 关系白名单）
- **query_cql 降级**：保留为底层工具，不直接暴露给 Agent
- **利用同源性**：JSON ↔ 图谱 100% 匹配 → 实体标准化简单（直接按名称查）

### 6.3 伪代码

```python
class GraphRetriever:
    def retrieve(self, query, entities, relation_types=None, max_results=10) -> list[Evidence]:
        evidences = []
        for entity in entities:
            cypher = self._build_cypher(entity, relation_types)
            rows = self.graph.query(cypher)
            for row in rows:
                evidences.append(Evidence(
                    text=f"{row['s']} -{row['r']}-> {row['t']}",
                    source_type="graph", retrieval_method="graph",
                    graph_path=[row['s'], row['r'], row['t']],
                ))
        return evidences[:max_results]
```

### 6.4 与 JSON 的反查联动（本项目独特优势）

```
图谱查实体 → 得到关系（糖尿病 -DRUG-> 二甲双胍）
         → 用"糖尿病"反查 JSON 文档（详情、预防、病因）
         → 关系 + 详情 组合成完整回答
```

---

## 第 7 部分：EvidenceFusion（证据融合）

### 7.1 职责

多路证据（Hybrid + HyDE + Graph）融合：去重 → 归一化 → 加权 → TopN。

### 7.2 关键设计

- **按 text 去重**（保留权重最高的一路）
- **权重可配**（hybrid=1.0, graph=0.9, hyde=0.7）
- **可扩展**：未来加 image 路（multimodal 权重 0.8）

### 7.3 伪代码

```python
class EvidenceFusion:
    WEIGHTS = {"hybrid": 1.0, "graph": 0.9, "hyde": 0.7}

    def fuse(self, *evidence_lists, top_n=15) -> list[Evidence]:
        seen = {}
        for evs in evidence_lists:
            for ev in evs:
                if ev.text not in seen:
                    seen[ev.text] = ev
        ranked = sorted(seen.values(), key=lambda e: self.WEIGHTS.get(e.retrieval_method, 0.5), reverse=True)
        return ranked[:top_n]
```

---

## 第 8 部分：RetrievalRouter + MedicalAgent

### 8.1 RetrievalRouter（路由决策）

升级 IntentionService → MedicalQueryAnalyzer，输出结构化决策：

```json
{
  "intent": "medical_question",
  "query_type": "relation",       // fact | relation | symptom | mixed
  "entities": ["糖尿病", "二甲双胍"],
  "use_hyde": false,
  "use_graph": true,
  "reason": "问题询问药物关系，需查图谱"
}
```

### 8.2 MedicalAgent（编排核心）

```python
class MedicalAgent:
    def run(self, query):
        # 1. 路由决策
        plan = self.router.plan(query)

        # 2. Hybrid 永远运行
        hybrid_evs = self.hybrid.retrieve(query)

        # 3. 条件扩展
        hyde_evs = self.hyde.retrieve(query) if plan.use_hyde else []
        graph_evs = self.graph.retrieve(query, plan.entities) if plan.use_graph else []

        # 4. 融合
        final_evs = self.fusion.fuse(hybrid_evs, hyde_evs, graph_evs)

        # 5. 重排
        final_evs = self.reranker.rerank(query, final_evs)

        # 6. 构建上下文 + 生成
        context = build_context(final_evs)
        answer = self.llm.invoke(context + query)

        # 7. 带引用返回
        return answer, final_evs
```

### 8.3 系统提示词（医学 Agent 核心）

```
你是严谨的医学知识助手。
回答规则：
1. 优先基于检索证据作答，标注引用编号 [1][3]
2. 证据不足时明确说"资料未覆盖"，不编造
3. 涉及用药/治疗时，提示"请遵医嘱"
4. 区分"事实陈述"与"建议"
```

### 8.4 AgentToolbox 重构

```
以前：query_cql / get_weather / random_character
以后：hybrid_search / hyde_search / graph_search
（天气/动漫移出医学 Agent，或保留在单独 General Agent）
```

---

## 第 9 部分：接入层与前端

### 9.1 ChatService 瘦身

```python
def chat(question, historyId, username):
    agent = MedicalAgent()
    for chunk in agent.run(question):
        yield chunk
```

只负责：调 Agent + 流式返回 + 保存历史。**不知道检索细节**。

### 9.2 IntentionService bug 修复

```python
# 原来：读 is_security（错）
# 改为：
return {
    "is_medical": result.get("is_medical", False),
    "confidence": result.get("confidence", "low"),
    "category": result.get("category", ""),
}
```

### 9.3 SSE 扩展（前端展示检索过程）

```json
{"type": "trace", "data": {"route": ["hybrid", "graph"], "entities": ["糖尿病"]}}
{"type": "content", "content": "回答文本..."}
{"type": "evidence", "data": [{"text": "...", "source": "..."}]}
{"type": "done"}
```

前端展示：
```
参考来源:
[1] 《内科学》
[2] 医学百科

🔍 检索详情
Route: Hybrid ✓ / HyDE ✗ / Graph ✓
Latency: 1.8s
```

---

## 第 10 部分：评测体系与演进路线

### 10.1 评测数据集

**retrieval_test.jsonl**（检索质量）：
```json
{"query": "糖尿病有哪些典型症状？", "relevant_doc_ids": ["d_001"]}
{"query": "高血压患者不能吃什么？", "relevant_doc_ids": ["d_052"]}
```

**router_test.jsonl**（路由正确性）：
```json
{"query": "糖尿病和二甲双胍什么关系？", "expected_route": {"hyde": false, "graph": true}}
{"query": "最近总喝水还变瘦", "expected_route": {"hyde": true, "graph": false}}
```

### 10.2 评测指标

- **检索**：Recall@5 / Recall@10 / MRR / nDCG
- **路由**：Router Accuracy / Graph Precision / Graph Recall / HyDE Precision
- **回答**：答案准确率（人工标注或 LLM-as-judge）
- **性能**：延迟（分阶段计时）

### 10.3 消融实验（答辩核心数据）

| 系统 | Recall@5 | MRR | 延迟 |
|---|---|---|---|
| A. Dense | — | — | — |
| B. Dense+BM25 | — | — | — |
| C. B+RRF | — | — | — |
| D. C+Reranker | — | — | — |
| E. D+HyDE | — | — | — |
| F. D+Graph | — | — | — |
| G. **Adaptive Agent** | — | — | — |

> 用真实数据证明每一层改造的价值。

### 10.4 实施顺序（10 步）

| 步 | 任务 | 先别做 |
|---|---|---|
| 1 | medical.json → 结构化文档 → Chroma + BM25 | 不碰 Agent |
| 2 | 封装 HybridRetriever | 不碰多模态 |
| 3 | 新增 Evidence 模型 | 不碰 LangGraph |
| 4 | 升级 HydeRetriever（医学提示词）| 不做复杂 Router |
| 5 | 建 Retrieval Evaluation | 不追求 UI |
| 6 | GraphRetriever（复用 query_cql 逻辑）| 不让 LLM 任意 Cypher |
| 7 | RetrievalRouter（升级 IntentionService）| 这时才 Agent 化 |
| 8 | MedicalAgent 编排 + 提示词 | |
| 9 | 消融实验 | |
| 10 | 前端 SSE 展示 | 然后进 Phase 2 多模态 |

### 10.5 Phase 2：多模态演进（后续）

```
Adaptive Medical RAG Agent
        │
        ▼
   多模态扩展
   ├─ 医学图片 caption → 文本向量
   ├─ CLIP/SigLIP 图文统一向量
   ├─ Vision LLM（图片分析）
   └─ 图片 Agent 工具
```

---

## 附：风险清单与预案

| 风险 | 影响 | 预案 |
|---|---|---|
| Chroma 旧 CVE 数据 | 检索结果错 | 独立 collection/path |
| Embedding 模型缺失 | 启动失败 | 实施前确认 `C:/model/...` |
| 4070 显存（8G）| Reranker OOM | 顺序加载，不同时跑大模型 |
| Ollama 意图识别慢 | 路由延迟 | 改用 GLM（LLMService）或缓存 |
| Neo4j 未启动 | Agent 崩溃 | 启动检测 + 降级到 Hybrid-only |
| GLM API 限流 | 生成失败 | 失败重试 + DeepSeek 备用 |
| Cypher 构造错误 | 图谱查询失败 | 代码构造 + 白名单，不靠 LLM 写 |
| 医疗回答风险 | 误导用户 | 提示词强制"遵医嘱"+ 免责声明 |
