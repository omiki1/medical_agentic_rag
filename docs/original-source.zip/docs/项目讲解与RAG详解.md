# 医疗疾病知识库 RAG 系统 — 项目详解与 RAG 运用指南

> **定位**：这是一份面向开发者/学习者的**超详细项目讲解 PDF**。它把 `medical_disease_db`（原 `rag_system_v2`）这个"FastAPI + Vue3 + LangChain + Chroma + Neo4j + Agent"的**医疗知识图谱 RAG 问答系统**讲透：项目架构、技术栈、每个 API 函数的用法、RAG 各构件（向量检索 / BM25 / RRF / Reranker / Agent）的职责分工，以及如何参考 GitHub 上同类项目做进一步优化。

---

## 目录

1. [项目概述](#1-项目概述)
2. [系统架构与调用链](#2-系统架构与调用链)
3. [后端框架与 API 详解（FastAPI）](#3-后端框架与-api-详解fastapi)
4. [AI 与大模型服务（LLM / Embedding / 意图识别）](#4-ai-与大模型服务llm--embedding--意图识别)
5. [RAG 检索管线详解（本项目核心职责）](#5-rag-检索管线详解本项目核心职责)
6. [Agent 智能体（LangChain create_agent）](#6-agent-智能体langchain-create_agent)
7. [数据构建与灌库（create_data）](#7-数据构建与灌库create_data)
8. [前端框架与使用（Vue3 / Vite / Element Plus / SSE）](#8-前端框架与使用vue3--vite--element-plus--sse)
9. [RAG 项目运用与职责的详细展开](#9-rag-项目运用与职责的详细展开)
10. [多模态 RAG 演进指南](#10-多模态-rag-演进指南)
11. [参考 GitHub 同类项目与优化建议](#11-参考-github-同类项目与优化建议)
12. [部署与环境清单 / 常见坑](#12-部署与环境清单--常见坑)
13. [附录：核心 API 函数速查](#13-附录核心-api-函数速查)

---

## 1. 项目概述

### 1.1 项目定位

这个项目是一个**面向医疗领域的知识图谱增强问答系统**。它把几种典型的大模型工程能力串成一条完整的链路：

- **对话前端**：Vue 3 + Element Plus 的赛博朋克风聊天界面
- **后端服务**：FastAPI（Python）提供 REST + SSE 流式接口
- **大模型**：DeepSeek / GLM（智谱）双模型接入
- **知识库（RAG）**：Chroma 向量库 + BM25 关键词检索 + RRF 多路融合 + Reranker 重排
- **知识图谱**：Neo4j 图数据库存疾病、症状、药物、科室、食物、检查项目等实体关系
- **Agent 智能体**：LangChain `create_agent` 驱动，Agent 可自主决定调用图谱查询、天气、动漫角色等工具

### 1.2 核心能力

| 能力 | 说明 |
|------|------|
| 密码 / 验证码 / 游客登录 | JWT 签发 + Redis 黑名单 + 角色权限（user/admin/guest） |
| 邮箱验证码 | SMTP 发码 + Redis 存码(60s) |
| 流式对话 | 前端 `fetchEventSource` 消费 SSE，后端 `StreamingResponse` 逐字返回 |
| 医疗知识问答 | Agent 调 `query_cql` 查 Neo4j 医疗图谱 |
| RAG 文本检索 | Chroma 向量 + BM25 关键词 + RRF 融合 + bge-reranker 重排 |
| 工具扩展 | 天气查询（高德 API）、动漫角色抽取（AniList GraphQL） |

### 1.3 技术栈速览

| 层 | 技术 | 版本/形式 |
|----|------|----------|
| 后端语言 | Python | 3.12 |
| Web 框架 | FastAPI | 路由 + Pydantic 模型 + 依赖注入 |
| ASGI 服务器 | Uvicorn | `uv.run(app="main:app")` |
| 大模型框架 | LangChain | `ChatOpenAI` / `create_agent` / `@tool` |
| LLM | DeepSeek + GLM(智谱) | OpenAI 兼容接口 |
| 向量库 | Chroma (langchain_chroma) | 持久化 + embedding |
| Embedding | HuggingFace | `paraphrase-multilingual-MiniLM-L12-v2` |
| 重排 | FlagEmbedding | `bge-reranker-large` |
| 图数据库 | Neo4j | `langchain_neo4j.Neo4jGraph` |
| 关系库 | MySQL (pymysql) | users / history / history_summary |
| 缓存 | Redis | JWT 黑名单 / 验证码 |
| 前端 | Vue 3 + Vite | `<script setup>` SFC |
| UI 库 | Element Plus | 中文语言包 |
| 状态管理 | Pinia | （已引入，本项目用组合式 API + ref 为主） |
| 路由 | vue-router | history 模式 |
| HTTP | axios | 拦截器带 Bearer token |
| SSE | `@microsoft/fetch-event-source` | 流式响应 |
| Markdown | markdown-it | 前端渲染 AI 回答 |

### 1.4 目录结构

```
medical_disease_db/
├── backend/
│   ├── main.py                 # FastAPI 入口，注册路由/CORS/静态资源
│   ├── .env                    # 环境变量（JWT/DB/Redis/模型路径/API Key）
│   ├── common/                 # 公共组件
│   │   ├── MySQLUtil.py        # MySQL 连接
│   │   ├── RedisUtil.py        # Redis 连接
│   │   ├── JWTUtil.py          # 生成/校验 JWT
│   │   ├── JWTDecode.py        # 依赖注入 get_current_user
│   │   ├── RolePermission.py   # has_roles 权限校验
│   │   └── HashPwdUtil.py      # 密码哈希（bcrypt）
│   ├── auth/                   # 认证模块（controller/service/dao/entity）
│   ├── user/                   # 用户模块
│   ├── chat/                   # 聊天模块
│   ├── ai/                     # 大模型/向量/意图服务
│   │   ├── LLMService.py       # DeepSeek + GLM 单例
│   │   ├── VectorStoreService.py # Embedding + Chroma 单例
│   │   ├── IntentionService.py # 医疗意图识别（Ollama）
│   │   └── Load*.py            # 兼容转发层
│   ├── rag/                    # RAG 检索组件
│   │   ├── VectorRetriever.py  # 向量检索
│   │   ├── BM25Retriever.py    # 关键词检索
│   │   ├── RRFUtil.py          # 多路融合
│   │   ├── RerankerUtil.py     # 重排
│   │   ├── HydeUtil.py         # HyDE（假设性文档）
│   │   └── SummaryHistory.py   # 历史摘要压缩
│   ├── agent/                  # Agent 智能体
│   │   ├── AgentToolbox.py     # 工具定义
│   │   └── build_agent.py      # GetAgent + create_agent
│   ├── create_data/            # 灌库脚本
│   └── static/                 # 静态资源（已 mount /static）
├── frontend/
│   ├── src/
│   │   ├── main.js             # 应用入口，挂 axios/ElementPlus/router
│   │   ├── App.vue             # 路由容器
│   │   ├── router/index.js     # /login /chat
│   │   └── views/
│   │       ├── Login.vue       # 登录/注册/游客
│   │       └── Chat.vue        # 聊天 + SSE
│   └── vite.config.js
└── docs/                       # 文档
```

---

## 2. 系统架构与调用链

### 2.1 整体架构图

```
┌─────────────────────────────── 前端 (Vue3 + Element Plus) ───────────────────────────────┐
│  Login.vue（登录/注册/验证码/游客）        Chat.vue（聊天 + 历史栏 + SSE 流式 + Markdown）  │
│  axios 拦截器自动带 Bearer token          fetchEventSource 消费 SSE                        │
└──────────────┬─────────────────────────────────────────────────────────────┬─────────────┘
               │ HTTP REST                                                  │ SSE
┌──────────────▼─────────────────────────────────────────────────────────────▼─────────────┐
│                             后端 FastAPI  (localhost:8000)                                │
│  main.py: lifespan + include_router + CORS + StaticFiles(/static)                          │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌──────────┐                                      │
│  │ /auth   │  │ /users  │  │ /chat   │  │ /history │                                      │
│  │ 登录/登出│  │ 注册/资料│  │ 聊天SSE │  │ 历史事务 │                                      │
│  │ 验证码   │  │ 发验证码 │  │        │  │          │                                      │
│  └─────────┘  └─────────┘  └─────────┘  └──────────┘                                      │
│                  ↓                                                                         │
│        Controller → Service → DAO → MySQL/Redis                                           │
│        ChatService → GetAgent → create_agent → 工具调用                                   │
└──────────────┬──────────────────────────────────────┬────────────────────────────────────┘
               │                                        │
     ┌─────────▼──────────┐                   ┌─────────▼──────────┐
     │   RAG 检索管线      │                   │   Agent 工具        │
     │  Vector  + BM25    │                   │  query_cql(Neo4j)  │
     │  → RRF 融合         │                   │  get_weather(高德) │
     │  → Reranker 重排   │                   │  random_character  │
     └────────────────────┘                   └─────────┬──────────┘
                                                        │
                                              ┌─────────▼──────────┐
                                              │  Neo4j 医疗知识图谱 │
                                              │  Disease/Symptom/  │
                                              │  Drug/Department/  │
                                              │  Food/Check        │
                                              └────────────────────┘
```

### 2.2 聊天调用链（真实代码）

```
前端 Chat.vue 输入问题，回车
  → fetchEventSource("http://localhost:8000/chat/chat", { method:'POST', body:{question, historyId} })
  → backend/chat/controller/ChatController.py 的 @chat_router.post("/chat")
  → 依赖注入 has_roles(["user","admin"]) 校验 token
  → ChatService.chat(question, historyId, username)      # 精简版：不传历史
  → GetAgent().run(question)                             # agent/build_agent.py
  → create_agent(model=GLM, tools=AgentToolbox.get_tools(), system_prompt=...)
  → agent.stream({"messages": [("user", question)]})
  → 逐 chunk 提取 model.messages[].content 并 yield
  → ChatController 用 StreamingResponse 以 SSE 格式 yield "data:{...}\n\n"
  → 前端 onmessage 解析 JSON，逐字累加 s，更新 messages[last].content
  → [DONE] 时调 saveConversationResult 持久化
```

### 2.3 分层架构（Controller / Service / DAO / Entity）

本项目采用经典的**三层分层**：

- **Controller（路由层）**：定义 URL、请求方法、依赖注入（鉴权）、请求体 Pydantic 模型、返回响应。**保持轻量**，不做业务逻辑。
- **Service（业务层）**：组装业务逻辑。例如 `AuthService` 做密码校验、发 token；`UserService` 做发验证码、注册；`HistoryService` 做历史查询/保存；`ChatService` 负责任何 agent 编排前的薄层。
- **DAO（数据访问层）**：直接用 SQL 访问 MySQL，或用工具访问外部。例如 `UsersDao`、`ChatDao`、`HistoryDao`。
- **Entity（数据模型）**：Pydantic `BaseModel`，既做请求体校验也做传输对象。

> **工程建议**：Controller 引用 Service，Service 引用 DAO；Entity 只在边界传递。这套分层让"逻辑清晰、易测试、易替换存储/模型"。

---

## 3. 后端框架与 API 详解（FastAPI）

### 3.1 入口 `main.py`

`main.py` 是 FastAPI 的入口，核心做了四件事：

**① 生命周期（lifespan）**
```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def start_end_run(app):
    print("启动项目")          # yield 前：启动时执行
    yield
    print("关闭项目")          # yield 后：关闭时执行

app = FastAPI(lifespan=start_end_run)
```
- `yield` 之前初始化资源（如连接池、模型预热），之后在 `yield` 后清理。
- 需要跨接口共享的变量放 `app.state.xxx`，接口内用 `request.app.state.xxx` 取。

**② 注册子路由**
```python
app.include_router(auth_router,  prefix="/auth",  tags=['auth'])
app.include_router(users_router, prefix="/users", tags=['user'])
app.include_router(chat_router,  prefix="/chat",  tags=['chat'])
app.include_router(history_router, prefix="/history", tags=['history'])
```
- `prefix`：统一访问前缀，如 `/auth/login`。
- `tags`：Swagger UI 里显示的模块名。

**③ 静态资源**
```python
from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory="static"), name="static")
```
- 把 `backend/static` 目录暴露为 `http://localhost:8000/static/...`，用于图片等静态资源（多模态扩展时会用到）。

**④ CORS 跨域**
```python
app.add_middleware(CORSMiddleware,
    allow_credentials=True, allow_methods=["*"],
    allow_origins=["http://localhost:8080"],  # 前端 Vite 端口
    allow_headers=["*"])
```
- **要点**：跨域配置必须放在启动块之前，否则不生效。
- `allow_origins` 只放行前端开发端口（Vite 默认 8080）。

**⑤ 启动**
```python
if __name__ == '__main__':
    import uvicorn as uv
    uv.run(app="main:app", host="localhost", port=8000, reload=False)
```

### 3.2 Pydantic 请求/响应模型

后端用 Pydantic `BaseModel` 定义入参和出参。例如：

```python
# chat/entity/ChatEntity.py
from pydantic import BaseModel
class ChatEntity(BaseModel):
    question: str
    historyId: int

# chat/entity/ConversationResultEntity.py
from pydantic import BaseModel, Field
class ConversationResultEntity(BaseModel):
    question: str = Field(..., description="问题")
    username: str = Field(..., description="用户名")
    parentId: int = Field(..., description="父会话 id（0 表示新会话第一问）")
    answer: str = Field(..., description="回答")
```

`Field(..., description=...)` 会出现在 Swagger UI 的字段说明里。`EmailStr`（需 `pydantic[email]`）自动校验邮箱格式，`min_length/max_length` 约束长度。

### 3.3 认证与 JWT

**生成 token（`common/JWTUtil.py`）**
```python
from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
import secrets

def create_access_token(data: dict):
    copy_data = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES")))
    copy_data.update({
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "user_id": data.get("user_id"),
        "username": data.get("username"),
        "role_name": data.get("role_name"),
        "jti": secrets.token_hex(8),   # 唯一 id，用于黑名单
    })
    return jwt.encode(copy_data, key=os.getenv("SECRET_KEY"), algorithm="HS256")
```

**校验 token + Redis 黑名单（`verify_token`）**
```python
def verify_token(token):
    try:
        payload = jwt.decode(token, key=os.getenv("SECRET_KEY"), algorithms=["HS256"])
    except JWTError:
        raise HTTPException(status_code=401, detail="token已过期或错误")
    jti = payload.get("jti")
    if jti:
        r = RedisUtil.get_redis_conn()
        if r.exists(f"blacklist:{jti}"):   # 退出登录时写入
            raise HTTPException(status_code=401, detail="token已失效，请重新登录")
    return payload
```

**依赖注入 `get_current_user`（`common/JWTDecode.py`）**
```python
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def get_current_user(token: str = Depends(oauth2_scheme)):
    payload = verify_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="无法验证凭据",
                            headers={"WWW-Authenticate": "Bearer"})
    return payload
```

**角色权限 `has_roles`（`common/RolePermission.py`）**
```python
def has_roles(*allowed_roles: list):
    def user_permission(authorization: str = Header(None)):
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="缺少认证信息")
        token = authorization.split(" ")[1]
        current_user = get_current_user(token)
        if current_user['role_name'] in allowed_roles[0]:
            return current_user['username']   # 返回 username 字符串
        else:
            raise HTTPException(status_code=403, detail="无访问权限")
    return user_permission
```

**用法**：`username: str = Depends(has_roles(["user", "admin"]))`。注意返回的是 `username` 字符串（不是 dict），所以路由函数里直接 `username` 用，不要再 `['username']`。

> **面试/工程亮点**：用 `jti` 实现**登出即失效**；用 `role_name` 实现**角色门禁**；用 `Header(None)` 从请求头取 `Authorization: Bearer xxx`。

### 3.4 认证 Service（`auth/AuthService.py`）

- `password_login`：按邮箱查用户 → bcrypt 校验密码 → 签发 JWT。
- `login_by_code`：查 Redis 里存的值比对验证码 → 校验通过删 key → 签发 JWT。
- `guest_login`：直接签发 `role_name="guest"` 的 JWT（无需密码，用于测试权限拦截）。
- `logout`：把当前 token 的 `jti` 写进 Redis 黑名单，`ex` 设为 token 剩余秒数。

### 3.5 用户 Service（`user/UserService.py`）

- `send_email`：校验邮箱存在 → 生成 4 位验证码 → SMTP 发邮件 → `r.set(email, code, ex=60)` 存 60 秒。
- `register_user`：校验邮箱未注册 → `PasswordManager.hash_password` → `UsersDao.add_user`（角色后端硬编码 `user`，防前端越权）。
- `get_profile`：按 email 查用户资料。

### 3.6 聊天 Controller（SSE 流式）

```python
@chat_router.post("/chat")
def chat(chat_entity: ChatEntity, username: str = Depends(has_roles(["user", "admin"]))):
    def generator():
        for chunk in ChatService.chat(chat_entity.question, chat_entity.historyId, username):
            yield f"data:{json.dumps({'content': chunk})}\n\n"   # SSE 数据帧
        yield f"data:{json.dumps({'content': '[DONE]'})}\n\n"    # 结束帧
    return StreamingResponse(content=generator(), media_type="text/event-stream")
```

- 用 `StreamingResponse(media_type="text/event-stream")` 实现 SSE。
- 每帧格式 `data:{json}\n\n`，前端 `onmessage` 拿到 `e.data` 再 `JSON.parse`。
- 结束时发送 `[DONE]` 信号，前端据此停止接收并保存。

### 3.7 历史记录 Controller（`chat/controller/HistoryController.py`）

| 接口 | 方法 | 功能 |
|------|------|------|
| `/history/queryHistoryMenu` | GET | 查当前用户会话菜单（parent_id=0 的会话） |
| `/history/conversationLog` | GET | 查某会话的完整对话（user/assistant 交替） |
| `/history/deleteConversationResult` | GET | 删除会话（含子记录 + 联动删 history_summary） |
| `/history/saveConversationResult` | POST | 保存一轮问答，返回新 history_id |

### 3.8 公共组件

| 组件 | 作用 |
|------|------|
| `MySQLUtil.get_mysql_conn()` | 返回 pymysql 连接（DictCursor） |
| `RedisUtil.get_redis_conn()` / `close_redis_conn()` | Redis 连接/关闭 |
| `HashPwdUtil.PasswordManager` | `hash_password` / `verify_password`（bcrypt） |
| `JWTUtil.create_access_token` / `verify_token` | JWT 签发/校验 |

---

## 4. AI 与大模型服务（LLM / Embedding / 意图识别）

### 4.1 `LLMService`（单例，管理 DeepSeek 与 GLM）

```python
class LLMService:
    _deepseek = None
    _glm = None

    @classmethod
    def get_deepseek(cls) -> ChatOpenAI:
        if cls._deepseek is None:
            cls._deepseek = ChatOpenAI(
                api_key=SecretStr(os.getenv("CHAT_OPENAI_API_KEY")),
                base_url="https://api.deepseek.com",
                model="deepseek-v4-flash",
                streaming=True, temperature=0.5, top_p=1,
            )
        return cls._deepseek

    @classmethod
    def get_glm(cls) -> ChatOpenAI:
        if cls._glm is None:
            cls._glm = ChatOpenAI(
                api_key=SecretStr(os.getenv("GLM_API_KEY")),
                base_url="https://open.bigmodel.cn/api/paas/v4/",
                model="glm-4.5-air",
                streaming=True, temperature=0.5, top_p=1,
            )
        return cls._glm
```

**要点**：
- 把原来 `LoadLLM.py`(DeepSeek) / `LoadLLM2.py`(GLM) 的 `global llm` 收进**类属性**，懒加载 + 单例。
- `ChatOpenAI` 用 OpenAI 兼容接口，传入 `base_url` 即可切换 DeepSeek / 智谱。
- `SecretStr` 避免明文打印 key，符合安全规范。
- `streaming=True` 支持流式（Agent 逐字输出依赖它）。

> **改造意义**：老的 `LoadLLM.py` 等文件被保留为**兼容转发层**，新代码应统一走 `LLMService`。

### 4.2 `VectorStoreService`（单例，Embedding + Chroma）

```python
class VectorStoreService:
    _embedding = None
    _chroma = None

    @classmethod
    def get_embedding_model(cls) -> HuggingFaceEmbeddings:
        if cls._embedding is None:
            cls._embedding = HuggingFaceEmbeddings(
                model_name=os.getenv("EMBEDDING_MODEL_PATH"),
                model_kwargs={"device": "cuda", "local_files_only": True},
            )
        return cls._embedding

    @classmethod
    def get_chroma(cls) -> Chroma:
        if cls._chroma is None:
            cls._chroma = Chroma(
                collection_name=os.getenv("COLLECTION_NAME"),
                persist_directory=os.getenv("CHROMA_PATH"),
                embedding_function=cls.get_embedding_model(),
            )
        return cls._chroma
```

**要点**：
- Chroma 需要 embedding 函数，二者天然绑定所以放同一个单例类。
- `local_files_only=True` 强制用本地模型（`C:/model/paraphrase-multilingual-MiniLM-L12-v2`），避免每次联网下载。
- `device="cuda"` 用 GPU 推理。

### 4.3 `IntentionService`（医疗意图识别，Ollama 本地模型）

```python
class IntentionService:
    _llm = None
    _system_prompt = '''你是一个专业的医学领域意图识别专家。…「输出 JSON」…'''

    @classmethod
    def _get_llm(cls) -> ChatOllama:
        if cls._llm is None:
            cls._llm = ChatOllama(model="qwen3:1.7b", base_url="http://localhost:11434")
        return cls._llm

    @classmethod
    def recognize(cls, question: str) -> dict:
        rs = cls._llm.invoke([{"role":"system","content":cls._system_prompt},
                              {"role":"user","content":question}])
        try:
            result = json.loads(rs.content)
        except Exception:
            result = {}
        return {"is_security": bool(result.get("is_security", True)),
                "confidence": result.get("confidence", "low")}
```

- 用本地 Ollama 的 `qwen3:1.7b`，不走网，便宜。
- 返回 `{is_medical, confidence, category}`，可用于路由：是否走 RAG/图谱。

> 注意：`IntentionService.recognize` 返回的字段是 `is_security`（早期代码未完全从"网络安全"迁到"医疗"，是一个遗留小问题，优化时统一改 `is_medical`）。

### 4.4 兼容转发层

下面这些文件是**薄封装**，为了向后兼容旧调用，新代码应改用对应类：

| 旧文件 | 转发到 | 用法 |
|--------|--------|------|
| `ai/LoadLLM.py` | `LLMService.get_deepseek()` | `load_model()` |
| `ai/LoadLLM2.py` | `LLMService.get_glm()` | `load_model()` |
| `ai/LoadEmbeddingModel.py` | `VectorStoreService.get_embedding_model()` | `load_embedding_model()` |
| `ai/LoadChroma.py` | `VectorStoreService.get_chroma()` | `load_chrome_conn()` |
| `ai/intentionUtil.py` | `IntentionService.recognize()` | `intention_recognition(q)` |

---

## 5. RAG 检索管线详解（本项目核心职责）

这是本项目最核心、也最有讲解价值的部分。RAG（Retrieval-Augmented Generation，检索增强生成）把"大模型生成"和"外部知识库检索"结合起来，解决大模型**幻觉**、**知识过期**、**不知道私有/专业数据**的问题。

### 5.1 RAG 的标准流程

```
用户问题
  → ① 向量检索 (VectorRetriever.search):        Chroma 里按语义相似度取 Top-K
  → ② 关键词检索 (BM25Retriever.search_bm25):   jieba 分词 + BM25 打分取 Top-K
  → ③ 多路融合 (RRFUtil.rrf):                   Reciprocal Rank Fusion 把多路结果合并
  → ④ 重排序 (RerankerUtil.reranker_func):      bge-reranker-large 对 (query, doc) 打分排序
  → ⑤ 组装 Prompt:                              把最相关文档拼进上下文
  → ⑥ 大模型生成:                               基于上下文生成回答
```

### 5.2 ① 向量检索 `rag/VectorRetriever.py`

```python
import os
from dotenv import load_dotenv
from langchain_chroma import Chroma
from ai.VectorStoreService import VectorStoreService

load_dotenv()
chroma_conn = None

def load():
    global chroma_conn
    if chroma_conn is None:
        chroma_conn = Chroma(
            collection_name=os.getenv('COLLECTION_NAME'),
            persist_directory=os.getenv('CHROMA_PATH'),
            embedding_function=VectorStoreService.get_embedding_model(),
        )
    return chroma_conn

def search(question: str, k: int = 20):
    retriever = load().as_retriever(search_kwargs={"k": k})
    return retriever.invoke(question)
```

- `Chroma(...).as_retriever(search_kwargs={"k": k})`：把向量库包装成 LangChain Retriever。
- `retriever.invoke(question)`：自动用 embedding 模型把 `question` 转向量，再在 collection 里找最近邻的文档。
- 返回 `Document` 列表（有 `page_content` 和 `metadata`）。
- **语义召回**：能匹配"同义改写、近义表达"，这是向量检索的强项。

### 5.3 ② 关键词检索 `rag/BM25Retriever.py`

```python
import jieba
from langchain_core.documents import Document
from rank_bm25 import BM25Okapi
from ai.VectorStoreService import VectorStoreService

STOP_WORDS = {"的","了","在","是","我","有","和",...}   # 中文停用词表

def tokenize(text: str) -> list:
    return [w for w in jieba.cut(text) if w.strip() and w.strip() not in STOP_WORDS]

def build_bm25_index(vector_db):
    data = vector_db.get()
    docs = []
    for i in range(len(data['ids'])):
        docs.append(Document(
            page_content=data['documents'][i],
            id=data['ids'][i],
            metadata={'source': data['metadatas'][i]},
        ))
    bm25 = BM25Okapi([tokenize(d) for d in data['documents']])
    return docs, bm25

_bm25 = None; _docs = None
def get_bm25_index(vector_db):
    global _bm25, _docs
    if _bm25 is None:
        _docs, _bm25 = build_bm25_index(vector_db)
    return _docs, _bm25

def search_bm25(bm25, question, docs, k=20):
    scores = bm25.get_scores(tokenize(question))
    top_idx = sorted(range(len(scores)), key=lambda x: scores[x], reverse=True)[:k]
    return [docs[i] for i in top_idx]
```

- **jieba 分词**：中文切词，`tokenize` 过滤停用词。
- **BM25Okapi**：经典概率检索模型，给文档打分（基于词频 + 逆文档频率）。
- 索引从 `vector_db.get()` 直接构建，数据源与向量库一致（同一份文档库）。
- **关键词召回**：能精确命中"专有名词/编号/特定术语"，弥补向量检索对稀有词的不足。

### 5.4 ③ 多路融合 `rag/RRFUtil.py`

```python
def rrf(vector_a: list, vector_b, bm25_result: list):
    scores_dict = {}
    docs_dict = {}
    for index, item in enumerate(vector_a, start=1):
        scores_dict[item.id] = scores_dict.get(item.id, 0) + round(1/(60+index), 7)
        docs_dict[item.id] = item
    for index, item in enumerate(vector_b, start=1):
        scores_dict[item.id] = scores_dict.get(item.id, 0) + round(0.7/(60+index), 7)
        docs_dict[item.id] = item
    for index, item in enumerate(bm25_result, start=1):
        scores_dict[item.id] = scores_dict.get(item.id, 0) + round(1/(60+index), 7)
        docs_dict[item.id] = item
    rrf_sort_idx = sorted(scores_dict.items(), key=lambda x: x[1], reverse=True)[:30]
    return [docs_dict[doc[0]] for doc in rrf_sort_idx]
```

**RRF（Reciprocal Rank Fusion，倒数排名融合）原理**：
- 不依赖各路分数的绝对值（各路打分尺度不同），只看**排名**。
- 每个文档在某路排名 `rank` 时，累加 `1/(k + rank)`（k 一般取 60）。
- 不同路的权重不同，这里 `vector_a` 全权重 1，`vector_b` 权重 0.7，`bm25` 全权重 1。
- 最后按总分排序取前 30。

> **关键点**：`item.id` 是文档的唯一标识（来自 Chroma 的 `ids`），用于跨路对齐同一文档。返回值是 `Document` 列表（已按融合后得分排序）。

### 5.5 ④ 重排序 `rag/RerankerUtil.py`

```python
from FlagEmbedding import FlagReranker

reranker = None

def reranker_func(data):
    global reranker
    if reranker is None:
        reranker = FlagReranker(
            model_name_or_path='C:/model/bge-reranker-large',
            use_fp16=True, devices=['cuda:0'])
    question = data['question']
    contexts = data['context']
    history = data['history']
    reranker_input = [(question, doc.page_content) for doc in contexts]
    scores = reranker.compute_score(reranker_input)
    doc_scores = list(zip(contexts, scores))
    doc_scores = sorted(doc_scores, key=lambda x: x[1], reverse=True)
    sorted_scores = [dot for dot, score in doc_scores]
    return {"context": sorted_scores, "question": question, "history": history}
```

- 用跨编码器重排模型 `bge-reranker-large`，对每个 `(query, doc)` 打一个相关性分。
- `compute_score([(q, doc1), (q, doc2), ...])` 批量打分。
- 按分数降序排，得到更精确 Top-K。
- **Reranker 比 Retriever 更准**：Retriever 先粗筛（快），Reranker 精排（准），这是 RAG 常见优化。

### 5.6 ⑤ HyDE（假设性文档）`rag/HydeUtil.py`

```python
def build_hyde_query(question: str):
    llm = LLMService.get_glm()
    rs = llm.bind(max_tokens=300).invoke([
        {'role':'system','content': HYDE_SYSTEM_PROMPT},
        {'role':'user','content': f'用户问题：{question}\n假设文档：'},
    ])
    doc = rs.content.strip()
    return doc if doc else question
```

- **HyDE（Hypothetical Document Embedding）**：先用大模型"凭空"写一段假定存在的答案文档，再用这段文档去检索。
- 原理：检索的问题向量往往语义不够"文档化"，而"假设文档"更接近库里的真实文档分布，检索更准。
- 这里 `system_prompt` 是"网络安全知识库检索助手"（遗留主题，可改医疗）。

### 5.7 ⑦ 历史摘要 `rag/SummaryHistory.py`

```python
def summary_history(history_list):
    ...
    rs = llm.bind(temperature=0.2, max_tokens=300).invoke([{'role':'user','content': prompt}])
    return rs.content.strip()[:MAX_SUMMARY_LEN]   # 硬截断 300 字
```

- 把多轮对话压缩成摘要，作为长上下文记忆，避免对话过长塞爆 context。
- 保留关键事实（数字、期限、结论），去掉客套。
- `test.py` 里还存了一份**带历史上下文的 ChatService 备用版**，以后要多轮记忆可参考还原。

---

## 6. Agent 智能体（LangChain create_agent）

### 6.1 工具包 `agent/AgentToolbox.py`

#### ⚠️ 关键坑：@tool 不能用实例方法（self）

LangChain 的 `@tool` 装饰器如果用于**带 self 的实例方法**，调用时会报：
`StructuredTool._run() got multiple values for argument 'self'`。

解决办法：在 `__init__` 里用**闭包函数捕获 graph**，工具函数本身不写 self。

```python
class AgentToolbox:
    def __init__(self, graph):
        self._graph = graph
        self._tools = self._build_tools()

    def _build_tools(self):
        graph = self._graph

        @tool(
            name_or_callable="query_cql",
            description="医疗知识图谱查询工具（Neo4j）。当用户问疾病相关的症状、治疗、药物、饮食时调用。…",
            args_schema=CQLTool,
        )
        def query_cql(query: str):
            """执行Cypher查询并返回结果"""
            print('正在查询图数据库')
            return graph.query(query)

        @tool(name_or_callable="get_weather", description="…", args_schema=WeatherTool)
        def get_weather(city: str):
            ...
            return ...

        @tool(name_or_callable="random_character", description="…")
        def random_character():
            ...
            return ...
        return [query_cql, get_weather, random_character]

    def get_tools(self):
        return self._tools
```

#### 工具参数 schema（pydantic）

```python
from pydantic import BaseModel, Field

class CQLTool(BaseModel):
    query: str = Field(..., description="Cypher 查询语句，用于查询 Neo4j 医疗知识图谱")

class WeatherTool(BaseModel):
    city: str = Field(..., description="城市名称，如 北京、上海")
```

`args_schema` 让大模型知道工具该填什么参数，`description` 让大模型知道**何时**用这个工具。

#### 工具一：`query_cql`（Neo4j 医疗图谱）

- 节点标签：`Disease`、`Symptom`、`Drug`、`Department`、`Food`、`Check`
- 关系类型：`DISEASE_SYMPTOM`、`DISEASE_DRUG`、`DISEASE_DEPARTMENT`、`DISEASE_DO_EAT`、`DISEASE_NOT_EAT`、`DISEASE_CHECK`
- 示例：
```cypher
MATCH (d:Disease)-[:DISEASE_SYMPTOM]->(s:Symptom)
WHERE d.name CONTAINS '高血压'
RETURN s.name AS symptom
```

#### 工具二：`get_weather`（高德天气 API）
- `requests.get("https://restapi.amap.com/v3/weather/weatherInfo", params={key, city, extensions:"base"})`
- 解析 `lives[0]` 返回天气/温度。

#### 工具三：`random_character`（AniList GraphQL）
- `requests.post("https://graphql.anilist.co", json={"query": gql, "variables": {"page": page}})`
- 用 `random.randint(1,60)` 随机挑一页，再从 chars 随机挑一个角色。

### 6.2 Agent 组装 `agent/build_agent.py`

```python
from langchain.agents import create_agent
from langchain_neo4j import Neo4jGraph

class GetAgent:
    def __init__(self):
        self.graph = Neo4jGraph(
            url="bolt://localhost:7687", username="neo4j",
            password="12345678", database="abc")
        self.llm = LLMService.get_glm()
        self.toolbox = AgentToolbox(self.graph)
        self.agent = create_agent(
            model=self.llm,
            system_prompt="""...（详细工具使用规则、回答风格、核心原则）""",
            tools=self.toolbox.get_tools(),
        )

    def run(self, question):
        chunks = self.agent.stream({"messages": [("user", question)]})
        for chunk in chunks:
            msgs = (chunk.get("model") or {}).get("messages") or []
            for m in msgs:
                content = getattr(m, "content", None)
                if isinstance(content, str) and content:
                    yield content
```

**要点**：
- `create_agent(model, system_prompt, tools)` 是 LangChain 1.x 的**Agent 工厂**，比旧版 `create_react_agent` 更简洁。
- `agent.stream({"messages": [("user", question)]})` 返回**增量 chunk**（dict）。
- 从 `chunk["model"]["messages"]` 提取每条 AIMessage 的 `content` 且 `isinstance(content, str)` 才 yield，避免把工具调用或非文本对象吐给前端。
- `system_prompt` 写得非常细：分成"工具调用规则 / 天气查询 / 医疗知识图谱 / 随机动漫角色 / 直接回答 / 回答风格 / 核心原则"七个部分，**指导 Agent 该何时用哪个工具、如何组织回答、如何避免伪造数据**。

---

## 7. 数据构建与灌库（create_data）

### 7.1 `create_data/LawDataBuild.py`

这是把 `.jsonl` 数据灌进 Chroma 的脚本：

```python
from langchain_core.documents import Document
from langchain_chroma import Chroma
from ai.VectorStoreService import VectorStoreService

data_file = Path(os.getenv('DATA_ROOT')) / 'cve_all.jsonl'
rows = []
with open(data_file, encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if line:
            rows.append(json.loads(line))

document = [Document(page_content=r['page_content'], metadata=r['metadata']) for r in rows]

Chroma.from_documents(
    documents=document,
    collection_name=collection_name,
    persist_directory=vector_db_path,
    embedding=VectorStoreService.get_embedding_model(),
    collection_metadata={"hnsw:space": 'cosine'},   # 余弦距离
)
```

- 每行 jsonl 一条：`{page_content, metadata}`。
- `Chroma.from_documents` 一步完成"切分→embedding→入库"，不用手动算向量。
- `collection_metadata={"hnsw:space":"cosine"}` 指定 HNSW 索引的相似度度量（余弦）。

> 多模态扩展时，`LawDataBuild.py` 是模板：把 `page_content` 换成图片描述，`metadata` 加 `type=image` + `image_path` 即可。

---

## 8. 前端框架与使用（Vue3 / Vite / Element Plus / SSE）

### 8.1 应用入口 `main.js`

```js
import { createApp } from 'vue'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import axios from 'axios'

axios.defaults.baseURL = 'http://localhost:8000/'
axios.defaults.headers.post['Content-Type'] = 'application/json'
axios.interceptors.request.use(cfg => {
    const token = sessionStorage.getItem('token')
    if (token) cfg.headers.Authorization = `Bearer ${token}`
    return cfg
})

const app = createApp(App)
app.use(router)
app.use(ElementPlus, { locale: zhCn })
app.config.globalProperties.$axios = axios
app.mount('#app')
```

**要点**：
- `axios.defaults.baseURL` 统一后端前缀。
- **拦截器**自动在所有请求头带 `Authorization: Bearer <token>`，登录态统一处理。
- Element Plus 注册时传 `zhCn` 中文包。
- 用 `app.config.globalProperties.$axios` 让组件里 `this.$axios` 或 `proxy.$axios` 可用。

### 8.2 路由 `router/index.js`

```js
const routes = [
    { path: '/', redirect: '/login' },
    { path: '/login', name: 'Login', component: () => import('../views/Login.vue') },
    { path: '/chat',  name: 'Chat',  component: () => import('../views/Chat.vue') },
]
const router = createRouter({ history: createWebHistory(), routes })
export default router
```

- `createWebHistory` 使用 HTML5 history 模式（URL 无 `#`）。
- 路由懒加载：`() => import(...)` 按需拆包。
- 当前已**临时移除登录鉴权守卫**（注释说明恢复方法在 docs），正式环境应加 `beforeEach`。

### 8.3 登录页 `Login.vue`

- 三种模式：`password`（密码）/ `code`（验证码）/ `register`（注册）。
- `sendEmail` → `GET /users/sendEmail?email=...`；`checkCode` → `POST /auth/loginByCode`。
- `passwordLogin` / `register` / `guestLogin` 分别调对应接口。
- 登录成功后 `sessionStorage.setItem('token', token)`，并 `parseJwt(token)` 解析 username/role 存 sessionStorage。
- `parseJwt`：手动 base64url 解码 JWT payload。

### 8.4 聊天页 `Chat.vue`（SSE 核心）

**SSE 流式对话**：

```js
import { fetchEventSource } from "@microsoft/fetch-event-source"

const SSE_URL = 'http://localhost:8000/chat/chat'

function chat() {
  isLoading.value = true
  let myQuestion = question.value.trim()
  question.value = ""
  if (myQuestion.length === 0) { ElMessage.warning("请输入内容"); return }
  isAtBottom.value = true
  messages.value.push({ role: 'user', content: myQuestion })
  messages.value.push({ role: 'assistant', content: 'AI正在努力的生成回复ing~~~' })

  let s = ''
  const token = sessionStorage.getItem("token")
  const controller = new AbortController()

  fetchEventSource(SSE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ question: myQuestion, historyId: currentChatId.value }),
    signal: controller.signal,
    onopen(response) {
      if (response.status === 401) { controller.abort(); ...; ElMessage.error('登录已失效'); throw new Error("登录已失效") }
      if (response.status === 403) { controller.abort(); ...; ElMessage.error('无资格使用'); throw new Error("无资格使用") }
      if (!response.ok) { controller.abort(); ...; throw new Error(`请求失败：${response.status}`) }
    },
    onmessage(e) {
      const data = JSON.parse(e.data).content
      if (data === '[DONE]') { controller.abort(); saveConversationResult(myQuestion, s); isLoading.value = false; return }
      s += data
      messages.value[messages.value.length - 1].content = s
    },
  })
}
```

**要点**：
- `fetchEventSource` 是 fetch 版 EventSource，支持 `POST` + 请求头（原生 EventSource 只能 GET）。
- `onopen` 处理 401/403：游客（guest）token 合法但无 `user/admin` 角色，后端返回 403，前端提示"无资格使用"。
- `onmessage` 每帧 `JSON.parse(e.data).content` 累加，直到 `[DONE]`。
- 用 `AbortController` 在出错或结束时主动断开。

**历史记录**：
- `query_history_menu` → `GET /history/queryHistoryMenu`
- `conversationLog` → `GET /history/conversationLog?historyId=...`
- `saveConversationResult` → `POST /history/saveConversationResult`
- `deleteConversationResult` → `GET /history/deleteConversationResult?historyId=...`

**自动滚动到底部**：
- `watch(messages, ..., {deep:true})`：监听流式更新（对象属性变化，浅监听不触发，须 deep）。
- 滚动阈值 `SCROLL_THRESHOLD=50`，上翻历史时 `isAtBottom=false` 停止跟随；点"回到底部"按钮恢复。

**Markdown 渲染**：
```js
const md = new MarkdownIt({ html: false, linkify: true, breaks: true })
function renderMarkdown(text) { return md.render(text || '') }
// 模板里 <div class="message-content" v-html="renderMarkdown(item.content)"></div>
```
- `html:false` 转义原始 HTML，**防 XSS**。

---

## 9. RAG 项目运用与职责的详细展开

这一章把"RAG"这个抽象概念落到本项目每一个真实文件上，讲清**每个组件负责什么、怎么协作、为什么这么设计**。这是本文档的核心章节。

### 9.1 RAG 是什么、解决了什么

RAG = **Retrieval-Augmented Generation**。它把"大模型生成"和"外部知识检索"拼在一起：

```
生成前：先到知识库里检索与问题相关的资料
生成时：把资料拼进 Prompt，让模型"看着资料答"
```

**它解决的三个典型问题**：
1. **幻觉**：大模型对不熟悉的话题会编造。RAG 让它只能基于真实资料回答。
2. **知识过期 / 私有数据**：模型训练数据截止某个时间，无法知道新法条、新药、私有病历。RAG 从库里取最新/独家数据。
3. **可溯源 / 可审计**：RAG 能定位"回答依据哪条资料"，便于人工复核。

### 9.2 本项目的 RAG 组件与职责分工（对照真实文件）

| 组件 | 文件 | 职责 | 一句话理解 |
|------|------|------|-----------|
| 数据源 | `create_data/*.jsonl` | 原始知识文本 + 元数据 | 知识库的"原料" |
| 灌库 | `create_data/LawDataBuild.py` | 把 jsonl 转 Document，嵌入、入库 | 把原料"排版"进向量库 |
| 向量库 | `ai/VectorStoreService.py`（持 `Chroma`） | 存向量 + 提供语义检索 | 文档的"语义索引" |
| 向量检索 | `rag/VectorRetriever.py` | 用语义相似度召回 Top-K | 找"意思相近"的文档 |
| 关键词检索 | `rag/BM25Retriever.py` | 用词频/逆文档频率召回 Top-K | 找"字面上匹配"的文档 |
| 多路融合 | `rag/RRFUtil.py` | 把多路召回按排名合并 | 综合各路结果，扬长避短 |
| 重排序 | `rag/RerankerUtil.py` | 对候选再做精确打分排序 | 精排，砍掉误召回 |
| 查询改写 | `rag/HydeUtil.py` | 生成假设文档增强检索 | 让 query 更"像文档" |
| 历史摘要 | `rag/SummaryHistory.py` | 压缩多轮对话记忆 | 长对话上下文化 |
| 生成 | `ai/LLMService.py`（GLM/DeepSeek） | 基于上下文生成回答 | 最终"讲出来" |
| 编排 | `agent/build_agent.py` | Agent 决定是否/如何检索、组织回答 | 大脑调度 |

### 9.3 一个字面工作流串联（真实调用假设）

假设用户问："高血压患者不能吃什么？"

```
① 意图识别（可选，IntentionService.recognize）→ 判断是否医疗相关，走图谱/RAG
② 向量检索  VectorRetriever.search("高血压患者不能吃什么", k=20)
            → Chroma 里按语义取回高血压相关饮食文档
③ 关键词检索 BM25Retriever.search_bm25(question, docs, k=20)
            → jieba 切词 → "高血压/不能/吃/什么" 命中含"高血压""忌口"的文档
④ 多路融合  RRFUtil.rrf(vector_a=向量结果, vector_b=..., bm25_result=关键词结果)
            → 按排名把两路候选合并，去掉重复，得到前 30
⑤ 重排      RerankerUtil.reranker_func({"question":q, "context":topN, "history":[]})
            → bge-reranker 对 (query, doc) 打分排序，只保留最相关的几篇
⑥ 组装Prompt → 把最相关文档的 page_content 拼进上下文
⑦ 大模型生成 → GLM 基于上下文输出"高血压忌高盐、高脂、辛辣……"
```

> 本项目当前**没有把 RAG 的①②③④⑤⑥ 全串进 Agent 的主链路**：`ChatService.chat()` 目前走的是 `GetAgent.run(question)`（Agent 调 Neo4j 工具），而纯文本 RAG 管线（Vector/BM25/RRF/Reranker）已单独实现但主要作为"底层检索能力"存在。**下一步优化的关键**就是把 RAG 检索结果真正喂给 Agent，形成 Agentic RAG。

### 9.4 为什么同时用向量 + BM25（混合检索）

- **向量检索**：擅长语义（同义词、改写、长尾），但**对专有名词/编号/罕见词**容易漏。
- **BM25 关键词检索**：擅长精确命中（法条编号、药名、术语），但**对同义改写**不敏感。
- **混合检索**：两者互补。用 RRF 把排名融合，得到比任何单一方式更稳的结果。

这就是业界常说的 **Hybrid Retrieval（混合检索）** 或 **检索融合（Retrieval Fusion）**。

### 9.5 为什么需要 Reranker（重排）

- Retriever（Chroma/BM25）是**粗筛**：速度快、召回广，但精度不高（可能召回一堆"语义相近但实际无关"的文档）。
- Reranker（跨编码器）是**精排**：对每个 `(query, doc)` 做深度编码打分，精度高，但慢。
- 标准做法：**先粗筛 Top-50，再精排 Top-5**。既保证速度又保证精度。

### 9.6 为什么需要 HyDE 和摘要

- **HyDE**：解决"问题太口语化，和文档语言不像"的问题。先让模型写一段假定答案，用这段"文档化"的文字去检索，命中率更高。
- **摘要**：多轮对话时 context 会被撑爆。只保留最近的若干轮 + 一段压缩摘要，兼顾记忆和成本。

### 9.7 RAG 职责边界（什么该归 RAG，什么不归）

| 场景 | 该不该走 RAG | 说明 |
|------|-------------|------|
| "高血压的常见症状" | ✅ 图谱/RAG | 结构化知识，查 Neo4j 或检索库 |
| "最近有什么新医保政策" | ✅ RAG | 需最新知识，RAG 取数 |
| "帮我写段 Python 代码" | ❌ 直接答 | 大模型自身知识足够，无需外部检索 |
| "现在北京天气" | ❌ 调天气工具 | 实时数据，走工具而非 RAG |
| "随机抽个动漫角色" | ❌ 调娱乐工具 | 娱乐功能，无需检索库 |

Agent 的 `system_prompt` 正是用来告诉模型**哪些该调工具、哪些直接答、哪些走检索**。

---

## 10. 多模态 RAG 演进指南

这部分从 `docs/多模态RAG演进指南/` 提炼，描述如何在现有文本 RAG 上叠加**图文通道**。

### 10.1 演进路线

```
现状：文本 RAG（Chroma + BM25 + RRF + Reranker + Agent）
  │
  ▼ 第1步（改动最小）：图片转文本灌库 —— 视觉模型把图转文字 → 进现有 Chroma
  │
  ▼ 第2步：多模态向量 —— CLIP 图文同一向量空间，双通道检索 + RRF 融合
  │
  ▼ 第3步：多模态生成 —— Qwen-VL / GLM-4V 图文回答
  │
  ▼ 第4步：Agent 多模态工具 —— AgentToolbox 加 search_medical_image / analyze_image
```

### 10.2 第1步：图片转文本

```python
Chroma.from_documents(
    documents=documents,   # page_content=图片描述, metadata={type:image, image_path:...}
    collection_name=collection_name,
    persist_directory=vector_db_path,
    embedding=VectorStoreService.get_embedding_model(),
    collection_metadata={"hnsw:space": "cosine"},
)
```

**关键**：图片本身不进向量，**图片的文字描述进向量**。用户提问"肺结节CT什么样"，靠描述命中。

### 10.3 第2步：CLIP 多模态向量

```python
from transformers import CLIPModel, CLIPProcessor

class MultimodalService:
    @classmethod
    def _get_model(cls):
        model = CLIPModel.from_pretrained(model_name)
        processor = CLIPProcessor.from_pretrained(model_name)
        return model, processor

    @classmethod
    def embed_image(cls, pil_image):
        inputs = processor(images=pil_image, return_tensors="pt")
        with torch.no_grad():
            return model.get_image_features(**inputs)[0]

    @classmethod
    def embed_text(cls, text: str):
        inputs = processor(text=text, return_tensors="pt")
        with torch.no_grad():
            return model.get_text_features(**inputs)[0]
```

- CLIP 把图/文映射到**同一个向量空间**，可直接算 cosine 相似度。
- 灌库：图片向量存独立 collection `image_kb`。
- 检索：`search_images_by_text`（文字→图） + `search_images_by_image`（图→图），再用现有 `RRFUtil.rrf` 融合（零改动复用！）。

### 10.4 第3步：多模态生成

用 OpenAI 兼容接口传 base64 图片：
```python
client.chat.completions.create(
    model="glm-4v-flash",
    messages=[{
        "role": "user",
        "content": [
            {"type":"text","text":"请描述这张医学图片的病灶特征"},
            {"type":"image_url","image_url":{"url": f"data:image/jpeg;base64,{b64}"}},
        ],
    }],
)
```

### 10.5 第4步：Agent 多模态工具

在 `AgentToolbox._build_tools()` 里加两个闭包工具（**仍不写 self**）：
```python
@tool(name_or_callable="search_medical_image", args_schema=ImageQueryInput, description="…")
def search_medical_image(query: str):
    from rag.MultimodalRetriever import search_images_by_text
    return [d.metadata.get("image_path") for d in search_images_by_text(query, k=5)]

@tool(name_or_callable="analyze_image", args_schema=ImageAnalyzeInput, description="…")
def analyze_image(image_path: str):
    from ai.VisionLLMService import VisionLLMService
    return VisionLLMService.generate("…", context_text="", image_paths=[image_path])
```
并在 `get_tools()` 返回列表加入这两个。前端加 `<el-upload>` 上传图片，`ChatEntity` 加 `image_path` 字段。

---

## 11. 参考 GitHub 同类项目与优化建议

参考开源社区 "**知识图谱 + RAG + Agent**" 这一类成熟项目（如 Yuxi-Know、GraphRAG、graphrag-hierarchical-chat、hybrid-rag-vectordb、scalable-agentic-rag-pipeline、cmw-rag 等），可以总结出本项目可借鉴的优化方向。

> 参考链接（GitHub/社区）：
> - 语析 Yuxi-Know（LightRAG + 知识图谱智能体）：`https://github.com/xerrors/Yuxi-Know`
> - GraphRAG hierarchical chat（父子分块 + 图谱抽取 + FastAPI SSE）：`https://github.com/nabaruns/graphrag-hierarchical-chat`
> - hybrid-rag-vectordb（向量 + 关键词混合检索）：`https://github.com/legenddev-star/hybrid-rag-vectordb`
> - scalable-agentic-rag-pipeline（生产级 Agentic RAG + 可观测/评估）：`https://github.com/arpon-kapuria/scalable-agentic-rag-pipeline`
> - cmw-rag（SGR + 智能索引 + 重排 + 元数据富化 + 父文档提取）：`https://github.com/arterm-sedov/cmw-rag`

### 11.1 检索质量优化（RAG 提分关键）

| 优化 | 说明 | 参考项目做法 |
|------|------|-------------|
| **多查询（Multi-Query）** | 用 LLM 把一个问题改写成多个角度的问题，分别检索再融合，减少"问法不对"导致的召回失败 | graphrag-hierarchical-chat 的多跳检索 |
| **HyDE** | 已有 `HydeUtil`，可接入 Agent 流程 | 与检索融合搭配 |
| **RRF-fusion / RAG-Fusion** | 已有 `RRFUtil`，可推广到多路（向量+BM25+多查询） | hybrid-rag-vectordb |
| **Parent-Document / 父子分块** | 检索小 chunk、返回大块上下文，兼顾精度与完整性 | graphrag-hierarchical-chat 的父子分块 |
| **元数据过滤（Metadata Filtering）** | 检索时按 `metadata`（疾病类别、来源、日期）过滤，缩小范围 | cmw-rag 的元数据富化 |
| **上下文压缩（Context Compression）** | 只保留与问题相关的部分 chunk | 先进 RAG 通用做法 |

### 11.2 引入图谱增强（GraphRAG）

- 本项目已有 Neo4j 图谱 + `query_cql` 工具。可以进一步做 **GraphRAG**：
  - 把图谱结构作为检索信号（不只查症状，还查"疾病-药物-科室"的完整关系链）。
  - 用 **multi-hop（多跳）Cypher** 查询关联实体，把图谱路径作为上下文。
  - 参考 Yuxi-Know / GraphRAG 的"实体关系抽取 + 图谱问答"。

### 11.3 Agent 化与编排（Agentic RAG）

- 目前 `ChatService.chat()` 只把 question 直接给 agent，**没有把 RAG 检索结果喂给 agent**。
- 优化成一版 **Agentic RAG**：Agent 决定是否检索 → 调 RAG 检索（向量+BM25+RRF+Reranker）→ 把检索结果作为工具返回 → 大模型基于上下文生成。
- 可以引入 **LangGraph** 做更复杂的多步编排（检索→重排→评审→重试→生成），参考 scalable-agentic-rag-pipeline。

### 11.4 可观测性与评估（生产级必备）

| 维度 | 建议 | 参考项目 |
|------|------|---------|
| **日志** | 记录每次检索的 query、召回文档、耗时、最终回答 | scalable-agentic-rag-pipeline（observability） |
| **评估** | 用 RAGAS 或 TruLens 评估 faithfulness / answer relevance / context precision | 社区 RAG 评估标准做法 |
| **成本/延迟** | 监控 token 消耗、LLM 调用次数、检索延时 | 生产化项目标配 |
| **配置化** | 把 k 值、权重、模型名、路径全部 .env 配置化 | cmw-rag 很强调配置 |

### 11.5 工程健壮性优化

| 问题 | 现状 | 建议 |
|------|------|------|
| 连接管理 | 每函数现建现关 `get_mysql_conn()` | 用连接池（SQLAlchemy / DBUtils） |
| Redis 生命周期 | 手动 `get_redis_conn()`/`close_redis_conn()` | 用 context manager 或连接池 |
| 模型单例 | 已做 `LLMService`/`VectorStoreService` 单例 ✅ | 继续保持，并统一线程安全 |
| 配置硬编码 | `Neo4jGraph` 密码写死；`Reranker` 路径写死 | 全走 `.env` |
| 安全 | `.env` 里含真实 key/密码 | 提交到 `.gitignore`，用密钥管理 |
| 异常处理 | 部分 DAO 无 try/finally | 统一异常处理 + 事务边界 |
| 类型 | 许多服务返回裸 dict | 用 Pydantic Response 模型统一结构 |
| 版权/主题遗留 | prompt 仍写着"网络安全/网络安全知识库" | 全面迁移到医疗术语 |

---

## 12. 部署与环境清单 / 常见坑

### 12.1 依赖清单（Python 后端）

```bash
# 大模型/向量
langchain-core
langchain-community
langchain-openai
langchain-chroma
langchain-huggingface
langchain-ollama
langchain-neo4j
langchain

# 向量/模型
chromadb
sentence-transformers (HuggingFaceEmbeddings)
FlagEmbedding          # bge-reranker
jieba                  # 中文分词
rank-bm25              # BM25

# Web/框架
fastapi
uvicorn
pydantic[email]
python-jose[cryptography]
passlib[bcrypt]
pymysql
redis

# 其他
python-dotenv
openai
requests
```

### 12.2 环境变量（`backend/.env`）

```env
SECRET_KEY=...
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_DATABASE=cyber_rag
MYSQL_PASSWORD=...
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
SENDER_EMAIL=...
SENDER_EMAIL_PASSWORD=...
SMTP_HOST=smtp.qq.com
SMTP_PORT=587
GLM_API_KEY=...
CHAT_OPENAI_API_KEY=...
COLLECTION_NAME=cyber_law
CHROMA_PATH=C:/workspace/rag_system_v2/backend/chroma
EMBEDDING_MODEL_PATH=C:/model/paraphrase-multilingual-MiniLM-L12-v2
RERANKER_MODEL_PATH=C:/model/bge-reranker-large
DATA_ROOT=...
WEATHER=...
```

> ⚠️ **安全提醒**：`.env` 里有真实 API Key / 密码 / 数据库账号，必须加入 `.gitignore`，不要提交到 Git。

### 12.3 常见坑

| 坑 | 原因 | 解决 |
|----|------|------|
| `StructuredTool._run() got multiple values for argument 'self'` | `@tool` 用到带 self 的实例方法 | **工具函数必须是闭包，不写 self**（见 AgentToolbox） |
| SSE 前端连不上 | 端口/CORS 没配 | 确认后端 `localhost:8000`，CORS `allow_origins` 放行 `http://localhost:8080` |
| 游客 403 | guest 有 token 但无 user/admin 角色 | 前端 `onopen` 处理 403，提示"无资格使用" |
| 向量检索无结果 | 未灌库 / collection 名或 path 不对 | 先跑 `LawDataBuild.py`，核对 `.env` 的 `COLLECTION_NAME`/`CHROMA_PATH` |
| 模型路径找不到 | `local_files_only=True` 且路径不存在 | 确认 `EMBEDDING_MODEL_PATH` 本地模型存在 |
| 重排 OOM | `bge-reranker-large` 吃显存 | 用 `use_fp16=True`，`devices` 指定 GPU，控制并发 |
| 图片 404（多模态） | 图片不在 `static`，或 URL 不对 | 放 `backend/static/images/…`，URL `http://localhost:8000/static/images/…` |
| Pydantic EmailStr 报错 | 未装 `pydantic[email]` | `pip install "pydantic[email]"` |

---

## 13. 附录：核心 API 函数速查

### 13.1 大模型 / 向量

| API | 示例 | 作用 |
|-----|------|------|
| `LLMService.get_glm()` / `get_deepseek()` | `llm = LLMService.get_glm()` | 获取 GLM/DeepSeek 模型（单例） |
| `ChatOpenAI(api_key, base_url, model, streaming)` | 见 LLMService | OpenAI 兼容大模型客户端 |
| `VectorStoreService.get_embedding_model()` | `emb = ...` | 获取 Embedding 模型（单例） |
| `VectorStoreService.get_chroma()` | `db = ...` | 获取 Chroma 向量库连接（单例） |
| `Chroma.from_documents(documents, collection_name, persist_directory, embedding, collection_metadata)` | 灌库 | 建库+嵌入+入库 |
| `Chroma(...).as_retriever(search_kwargs={"k":k})` | `retriever = db.as_retriever(...)` | 转成 LangChain Retriever |
| `retriever.invoke(question)` | `docs = retriever.invoke(q)` | 向量检索 |
| `HuggingFaceEmbeddings(model_name, model_kwargs)` | 见 VectorStoreService | HF embedding |
| `IntentionService.recognize(q)` | `res = IntentionService.recognize(q)` | 医疗意图识别 |

### 13.2 检索 / 融合 / 重排

| API | 示例 | 作用 |
|-----|------|------|
| `VectorRetriever.search(q, k)` | `docs = search(q, k=20)` | 向量检索入口 |
| `BM25Retriever.tokenize(text)` | `tokens = tokenize(text)` | 中文分词（jieba） |
| `BM25Retriever.build_bm25_index(vector_db)` | `docs, bm25 = build_bm25_index(db)` | 构建 BM25 索引 |
| `BM25Retriever.search_bm25(bm25, q, docs, k)` | `docs = search_bm25(bm25, q, docs, 20)` | BM25 关键词检索 |
| `RRFUtil.rrf(vector_a, vector_b, bm25_result)` | `docs = rrf(a, b, c)` | 多路融合 |
| `RerankerUtil.reranker_func(data)` | `res = reranker_func({"question":q,"context":ctx,"history":[]})` | 重排 |
| `HydeUtil.build_hyde_query(q)` | `hq = build_hyde_query(q)` | HyDE 查询改写 |
| `SummaryHistory.summary_history(hist)` | `s = summary_history(hist)` | 历史摘要压缩 |

### 13.3 Agent / 认证 / DB

| API | 示例 | 作用 |
|-----|------|------|
| `create_agent(model, system_prompt, tools)` | 见 build_agent.py | 组装 Agent |
| `@tool(name_or_callable, args_schema, description)` | 见 AgentToolbox | 定义工具（闭包） |
| `agent.stream({"messages":[("user",q)]})` | 见 run() | 流式运行 Agent |
| `has_roles(["user","admin"])` | 见 ChatController | 角色鉴权依赖 |
| `get_current_user` | 见 JWTDecode.py | 解析当前用户依赖 |
| `create_access_token(data)` | 见 JWTUtil | 签发 JWT |
| `verify_token(token)` | 见 JWTUtil | 校验 JWT + 黑名单 |
| `PasswordManager.hash_password(pwd)` / `verify_password` | 见 HashPwdUtil | bcrypt 哈希/校验 |
| `MySQLUtil.get_mysql_conn()` | 见 DAO | MySQL 连接 |
| `RedisUtil.get_redis_conn()` | 见服务层 | Redis 连接 |
| `StreamingResponse(content=gen(), media_type="text/event-stream")` | 见 ChatController | SSE 流式响应 |

### 13.4 前端

| API | 示例 | 作用 |
|-----|------|------|
| `fetchEventSource(url, {method, headers, body, onmessage})` | 见 Chat.vue | SSE 流式（POST） |
| `axios.defaults.baseURL` / 拦截器 | 见 main.js | 统一后端地址 + 带 token |
| `createRouter({history, routes})` | 见 router | Vue 路由 |
| `new MarkdownIt({html:false, linkify:true, breaks:true})` | 见 Chat.vue | Markdown 渲染（防 XSS） |
| `createApp(App).use(router).use(ElementPlus, {locale: zhCn})` | 见 main.js | 应用初始化 |
| `app.config.globalProperties.$axios` | 见 main.js | 全局 axios 挂载 |

---

## 结语

`medical_disease_db` 是一个**麻雀虽小、五脏俱全**的"医疗知识图谱 + RAG + Agent"全栈项目。它覆盖了：

- **FastAPI** 的分层（Controller/Service/DAO/Entity）与 REST/SSE
- **JWT + 角色** 的认证鉴权
- **LangChain** 的 `ChatOpenAI`、`create_agent`、`@tool`、`as_retriever`
- **RAG** 的向量检索、BM25、RRF 融合、Reranker 重排、HyDE、历史摘要
- **Neo4j** 图数据库与 Cypher 查询
- **Vue 3 + Element Plus + SSE** 的前端流式交互

希望这份文档能帮你把项目**从"能跑"提升到"懂它为什么这么设计、还能往哪优化"**。如果要在生产环境进一步打磨，请参考第 11 章的优化建议——尤其是把 RAG 检索真正接入 Agent 形成 **Agentic RAG**，并补上**可观测性与评估**。
