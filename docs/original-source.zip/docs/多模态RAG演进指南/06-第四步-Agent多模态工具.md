# 06 第四步（最贴合你现状）：Agent 多模态工具

你已经有 `AgentToolbox`（query_cql / get_weather / random_character）+ `create_agent`。
这一步把多模态能力**做成工具**，让 Agent 自主决定"要不要查图/分析图"。这是最贴合你架构的一步。

## 一、给 AgentToolbox 加两个工具

在 `backend/agent/AgentToolbox.py` 的 `_build_tools()` 里追加（保持"闭包函数"写法，别用 self！）：

```python
# 在 _build_tools() 内部，与 query_cql 等并列追加

class ImageQueryInput(BaseModel):
    query: str = Field(..., description="症状/疾病描述，如'边界不规则的皮疹'")


class ImageAnalyzeInput(BaseModel):
    image_path: str = Field(..., description="本地图片路径，如 static/images/xxx.jpg")


# ---------- 工具4：根据文字描述检索医学影像 ----------
@tool(
    name_or_callable="search_medical_image",
    description="""医学影像检索。当用户想看某种疾病/症状的影像图（如CT、皮肤镜图）时调用。
        根据文字描述在图库中检索相似图片。返回图片路径列表。""",
    args_schema=ImageQueryInput,
)
def search_medical_image(query: str):
    from rag.MultimodalRetriever import search_images_by_text
    docs = search_images_by_text(query, k=5)
    return [d.metadata.get("image_path") for d in docs]


# ---------- 工具5：分析本地图片 ----------
@tool(
    name_or_callable="analyze_image",
    description="""医学图片分析。当用户上传/提供一张图片，想了解病灶特征时调用。
        参数 image_path 是图片文件路径。返回分析文本。""",
    args_schema=ImageAnalyzeInput,
)
def analyze_image(image_path: str):
    from ai.VisionLLMService import VisionLLMService
    return VisionLLMService.generate(
        "请分析这张医学图片的病灶特征和可能的诊断方向",
        context_text="",
        image_paths=[image_path],
    )
```

## 二、get_tools() 更新

```python
return [query_cql, get_weather, random_character, search_medical_image, analyze_image]
```

> 现在 AgentToolbox 已经是 5 个工具：图谱查询、天气、动漫、图检索、图分析。Agent 会按 system_prompt 自行判断调用哪个。

## 三、改 system_prompt，告诉 Agent 什么时候用图工具

在 `backend/agent/build_agent.py` 的 `system_prompt` 加一段：

```
# 八、多模态工具

当用户想看疾病相关的影像图片（CT、X光、皮肤镜等）时，调用 search_medical_image。

当用户上传了一张图片（提供了 image_path）想分析时，调用 analyze_image。

图工具返回后，结合图片信息给用户自然的回答，不要机械输出路径。
```

## 四、用户上传图片怎么进 Agent（后端接收上传）

新建 `backend/chat/controller/UploadController.py`（或并入现有 controller）：

```python
# 简化版：接收前端 multipart 上传，存到 static/images/upload，返回路径
from fastapi import APIRouter, UploadFile, File
import uuid, os

upload_router = APIRouter(prefix="/upload", tags=["upload"])

@upload_router.post("/image")
async def upload_image(file: UploadFile = File(...)):
    ext = file.filename.rsplit(".", 1)[-1] or "jpg"
    name = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join("static", "images", "upload", name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(await file.read())
    return {"code": 200, "data": {"image_path": path}}
```

然后在 main.py 注册：

```python
from chat.controller.UploadController import upload_router  # 或合适位置
app.include_router(upload_router)
```

## 五、把图片路径传给 chat（聊天接口加可选参数）

`ChatEntity` 加字段（`backend/chat/entity/ChatEntity.py`）：

```python
from pydantic import BaseModel

class ChatEntity(BaseModel):
    question: str
    historyId: int
    image_path: str | None = None   # 新增：上传的图片路径
```

`ChatService.chat` 拿到 image_path 后，可把它注入 agent 的上下文或消息：

```python
# ChatService.chat 里（思路示意）
from agent.build_agent import GetAgent
agent = GetAgent()
# 如果有图片，先在消息里说明，让 agent 知道可调 analyze_image
if image_path:
    question = f"[用户上传图片: {image_path}] {question}"
for chunk in agent.run(question):
    yield chunk
```

（更完整做法：把图片作为消息内容传给多模态模型，这里先按"路径提示词"的方式打通链路。）

## 六、重要 API 函数说明

| API | 来源 | 作用 |
|-----|------|------|
| `@tool(name_or_callable, args_schema, description)` | langchain_core.tools | 定义工具。**必须闭包函数，不写 self**（前面踩过的坑！） |
| `tool.invoke({"query": ...})` | langchain | 测试工具独立调用 |
| `UploadFile` / `File(...)` | fastapi | 接收文件上传 |
| `uuid.uuid4()` | python | 生成唯一文件名 |
| `create_agent(model, tools, system_prompt)` | langchain.agents | 组装 agent，tools 换成 get_tools() 新列表 |

## 七、完成标准

- [ ] AgentToolbox 有 `search_medical_image` + `analyze_image`
- [ ] `GetAgent` 能创建成功，5 个工具注册正常
- [ ] 上传接口能存图片并返回路径
- [ ] 问"给我看肺结节CT图" → Agent 调 search_medical_image
- [ ] （提供路径后）"分析这张图" → Agent 调 analyze_image

> Agent 化是当前架构最自然的落点——你的 query_cql / get_weather 已经证明了"工具思维"是通的，多模态只是再加两个工具。