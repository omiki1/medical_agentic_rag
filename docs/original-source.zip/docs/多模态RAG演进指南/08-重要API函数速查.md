# 08 重要 API 函数速查表

按演进步骤整理的关键 API，复制即用。

## 一、灌库 / 向量（第 1、2 步）

| API | 示例 | 说明 |
|-----|------|------|
| `Chroma.from_documents(documents, collection_name, persist_directory, embedding, collection_metadata)` | `Chroma.from_documents(docs, collection_name="kb", persist_directory=path, embedding=emb, collection_metadata={"hnsw:space":"cosine"})` | 一次灌库建库（你现用） |
| `chromadb.PersistentClient(path)` | `client = chromadb.PersistentClient(path="backend/chroma")` | 直连持久化向量库（自定义向量时用） |
| `client.get_or_create_collection(name, metadata)` | `col = client.get_or_create_collection("image_kb", metadata={"hnsw:space":"cosine"})` | 拿/建 collection |
| `collection.add(ids, embeddings, metadatas, documents)` | `col.add(ids=["a"], embeddings=[vec], metadatas=[{"type":"image"}], documents=["描述"])` | 手动插向量 |
| `collection.query(query_embeddings, n_results)` | `col.query(query_embeddings=[vec], n_results=10)` | 按向量检索 |
| `Document(page_content, metadata)` | `Document(page_content="...", metadata={"type":"image"})` | LangChain 文档对象 |
| `VectorStoreService.get_embedding_model()` | `emb = VectorStoreService.get_embedding_model()` | 你的文本 embedding 单例 |

## 二、多模态 embedding（第 2 步）

| API | 示例 | 说明 |
|-----|------|------|
| `CLIPModel.from_pretrained(name)` | `model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")` | 加载 CLIP 图文模型 |
| `CLIPProcessor.from_pretrained(name)` | `proc = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")` | 图文预处理 |
| `model.get_image_features(**inputs)` | `vec = model.get_image_features(**proc(images=pil_img, return_tensors="pt"))[0]` | 图 → 向量 |
| `model.get_text_features(**inputs)` | `vec = model.get_text_features(**proc(text="皮疹", return_tensors="pt"))[0]` | 文 → 向量 |
| `torch.no_grad()` | `with torch.no_grad(): ...` | 推理省显存 |
| `Image.open(path).convert("RGB")` | `img = Image.open("a.jpg").convert("RGB")` | 读图转 RGB |

## 三、视觉 LLM 生成（第 3 步）

| API | 示例 | 说明 |
|-----|------|------|
| `OpenAI(api_key, base_url)` | `client = OpenAI(api_key=..., base_url="https://open.bigmodel.cn/api/paas/v4/")` | 兼容 GLM/Qwen 的客户端 |
| `client.chat.completions.create(model, messages)` | `resp = client.chat.completions.create(model="glm-4v-flash", messages=[...])` | 对话生成 |
| `resp.choices[0].message.content` | `text = resp.choices[0].message.content` | 取回答文本 |
| image content 块 | `{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,..."}}` | 图以 base64 data-url 传入 |
| `base64.b64encode(f.read()).decode()` | `b64 = base64.b64encode(f.read()).decode()` | 本地图 → base64 |
| `SecretStr(...).get_secret_value()` | `key = SecretStr(os.getenv("GLM_API_KEY")).get_secret_value()` | 取 API key 明文 |

## 四、Agent 工具（第 4 步）

| API | 示例 | 说明 |
|-----|------|------|
| `@tool(name_or_callable, args_schema, description)` | `@tool("analyze_image", args_schema=ImageAnalyzeInput, description="...")` | 定义工具。**必须闭包函数不写 self！** |
| `BaseModel` + `Field`（pydantic） | `class Input(BaseModel): query: str = Field(..., description="...")` | 工具参数 schema |
| `tool.invoke({...})` | `tool.invoke({"query": "皮疹"})` | 独立测试工具 |
| `create_agent(model, tools, system_prompt)` | `create_agent(model=llm, tools=toolbox.get_tools(), system_prompt="...")` | 组装 Agent（你已在用） |
| `UploadFile` / `File(...)` | `async def up(file: UploadFile = File(...))` | 接收上传 |

## 五、前端（第 7 步）

| API | 示例 | 说明 |
|-----|------|------|
| `fetchEventSource(url, {method, headers, body, onmessage})` | 见 Chat.vue | SSE 流式（现用） |
| `FormData.append('file', raw)` | `fd.append('file', file.raw)` | 传文件 |
| `axios.post(url, fd, {headers})` | `axios.post('/upload/image', fd, {headers})` | 上传 |
| `<el-upload :auto-upload="false">` | 见 07 文档 | 选图控件 |
| `StaticFiles(directory="static")` | 后端 `app.mount("/static", ...)` | 静态图可访问（已在 main.py） |

## 六、融合 / 重排（复用，无需改）

| API | 位置 | 说明 |
|-----|------|------|
| `RRFUtil.rrf(a, b, c)` | backend/rag/RRFUtil.py | 多路融合（多模态 = 文本+图+BM25） |
| `RerankerUtil.reranker_func(data)` | backend/rag/RerankerUtil.py | 结果重排 |
| `VectorRetriever.search(q, k)` | backend/rag/VectorRetriever.py | 文本检索入口 |