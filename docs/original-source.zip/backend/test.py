"""
【备用存档】带"历史上下文"的 ChatService 逻辑（当前未启用，仅作参考）。

当前生产用的 chat/service/ChatService.py 是【精简版】：不把历史传给 agent，只传 question。
这里保存了"历史上下文"版本的完整逻辑，以后需要把多轮历史传给 agent 时，可参考此文件还原。

用法说明（何时启用）：
1. 当前 GetAgent.run(question) 只接收 question 字符串。
2. 若要把历史上下文传给 agent，需让 run 接收 messages 列表（多轮对话），例如：
       messages = [("user", "之前问题"), ("assistant", "之前回答"), ("user", question)]
       await/agent.stream({"messages": messages})
3. 下面的 build_history_messages() 就是把数据库历史整理成这种 messages 的辅助函数。
   GetAgent.run 需相应改为接收 messages（见文末注释）。

依赖的 Service：
    from chat.service import HistoryService, SummaryHistoryService
    from rag.SummaryHistory import summary_history   （历史压缩，若需要长历史摘要时用）
"""


def build_history_messages(historyId: int, question: str, username: str):
    """
    从数据库读取该会话的历史，整理成 LangChain 的 messages 列表（多轮对话）。
    返回 (messages, summary_text)：
        messages      -> [("user", ...), ("assistant", ...), ..., ("user", question)]
        summary_text  -> 历史摘要文本（用于长上下文压缩时）
    """
    # 1) 取该会话完整历史（每条会话对应 user/assistant 两条）
    history = HistoryService.conversation_log(historyId)['data']

    # 2) 历史压缩逻辑（超过阈值时才触发摘要）
    n = int(len(history) / 2)
    i = n
    if (i - 1) % 3 == 0 and i > 3:
        summary = SummaryHistory.summary_history(history[(i - 4) * 2:(i - 1) * 2])
        SummaryHistoryService.update_summary(historyId, username, summary=summary)
    keep_msgs = (n - (n - 1) // 3 * 3) * 2

    # 3) 组装历史摘要
    summary_list = SummaryHistoryService.get_summary_list(historyId, username)['data']
    history_summary = " ".join(summary_list)

    # 4) 近 keep_msgs 条历史 + 摘要前缀 + 当前问题
    history = ([{'role': 'user', 'content': f'[此前对话摘要]{history_summary}'}]
               + history[-keep_msgs:])
    history.append({'role': 'user', 'content': question})

    # 5) 转成 messages 元组列表
    messages = [(m['role'], m['content']) for m in history]
    return messages, history_summary


"""
如果以后要让 agent 支持历史上下文，把 agent/build_agent.py 的 run 改成接收 messages：

    def run(self, messages):
        chunks = self.agent.stream({"messages": messages})
        for chunk in chunks:
            content = getattr(chunk, "content", None)
            if isinstance(content, str) and content:
                yield content

然后 ChatService.chat 里这样用：

    from chat.service.HistoryService import conversation_log   # 需 as 模块级导入
    from agent.build_agent import GetAgent
    messages, _ = build_history_messages(historyId, question, username)
    agent = GetAgent()
    for chunk in agent.run(messages):
        yield chunk
"""


if __name__ == '__main__':
    # 简单示例：打印某 historyId 的历史 messages（不实际跑 agent）
    # messages, summary = build_history_messages(historyId=1, question="高血压怎么治", username="test")
    # print(messages)
    print("test.py 为 ChatService 历史上下文的备用存档，当前生产 ChatService 为精简版。")
