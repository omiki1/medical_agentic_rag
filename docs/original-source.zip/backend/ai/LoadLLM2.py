"""[兼容转发层] LoadLLM2.py — 请改用 ai.LLMService。

原实现已合并进 LLMService（GLM），本文件保留为薄封装以兼容旧调用。
新代码请使用：from ai import LLMService; LLMService.get_glm()
"""

from ai.LLMService import LLMService


def load_model():
    """兼容旧接口：返回 GLM 模型（等价 LLMService.get_glm()）。"""
    return LLMService.get_glm()
