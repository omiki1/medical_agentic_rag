"""[兼容转发层] intentionUtil.py — 请改用 ai.IntentionService。

原实现已改造成 IntentionService 类，本文件保留为薄封装以兼容旧调用。
新代码请使用：from ai import IntentionService; IntentionService.recognize(question)
"""

from ai.IntentionService import IntentionService


def intention_recognition(question: str) -> dict:
    """兼容旧接口：安全领域意图识别。"""
    return IntentionService.recognize(question)
