"""[兼容转发层] LoadChroma.py — 请改用 ai.VectorStoreService。

原实现已合并进 VectorStoreService，本文件保留为薄封装以兼容旧调用。
新代码请使用：from ai import VectorStoreService; VectorStoreService.get_chroma()
"""

from ai.VectorStoreService import VectorStoreService


def load_chrome_conn():
    """兼容旧接口：返回 Chroma 向量库连接。"""
    return VectorStoreService.get_chroma()
