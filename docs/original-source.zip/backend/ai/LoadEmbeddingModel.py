"""[兼容转发层] LoadEmbeddingModel.py — 请改用 ai.VectorStoreService。

原实现已合并进 VectorStoreService，本文件保留为薄封装以兼容旧调用。
新代码请使用：from ai import VectorStoreService; VectorStoreService.get_embedding_model()
"""

from ai.VectorStoreService import VectorStoreService


def load_embedding_model():
    """兼容旧接口：返回 Embedding 模型。"""
    return VectorStoreService.get_embedding_model()
