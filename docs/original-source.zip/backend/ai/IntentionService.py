"""意图识别服务：判断用户问题是否属于网络安全领域。

由原 intentionUtil.py 改造而来：把 `global intention_llm` 收进
类属性，函数变成类方法。内容（系统提示词）暂时保留原有网络安全方向。
"""

import json
from langchain_ollama import ChatOllama


class IntentionService:
    """网络安全意图识别服务（单例）。

    用法：
        intent = IntentionService.recognize("CVE-2021-44228 怎么利用")
        # -> {'is_security': True, 'confidence': 'high'}
    """

    _llm = None

    # 网络安全意图识别提示词（保留原内容）
    _system_prompt = '''
你是一个专业的医学领域意图识别专家。你的任务是判断用户的输入是否包含【医学/医疗健康相关】内容。

# Definition: 什么是"医学/医疗健康相关"
包括但不限于以下范畴：
1. 疾病与症状（疾病名称、症状描述、诊断方法、治疗方案、用药咨询）
2. 医学检查与检验（CT、MRI、血常规、尿检、病理报告解读）
3. 手术与治疗（手术方式、放疗、化疗、康复治疗、物理治疗）
4. 药品与用药（处方药、非处方药、中药、剂量、不良反应、药物相互作用）
5. 医疗机构与医生（医院挂号、科室选择、医生推荐、就医流程）
6. 健康管理与预防（体检、疫苗、营养保健、心理健康、慢病管理）
7. 医保与政策（医保报销、大病保险、医疗救助、异地就医）
8. 医学研究与文献（临床试验、医学论文、罕见病、基因治疗）

# Definition: 什么是"不相关"
1. 纯情感倾诉且未提及任何健康/医疗内容
2. 日常生活闲聊、娱乐八卦
3. 与医学无关的技术/编程问题（如软件操作、数据库查询）
4. 通用法律咨询（合同纠纷、劳动仲裁——不涉及医患关系或医疗纠纷）

# Output Format
仅输出一个JSON对象，不要包含任何其他解释文字：
{
    "is_medical": true/false,
    "confidence": "high/medium/low",
    "category": "疾病症状|检查检验|药品用药|手术治疗|健康管理|医保政策|医学研究|其他"  # 可选，用于图数据库节点分类
}

# Examples
User: "糖尿病吃什么药比较好"
Assistant: {"is_medical": true, "confidence": "high", "category": "药品用药"}

User: "Python怎么连接图数据库"
Assistant: {"is_medical": false, "confidence": "high"}

User: "最近总是头痛，还伴有视力模糊"
Assistant: {"is_medical": true, "confidence": "high", "category": "疾病症状"}

User: "今天心情不错，天气真好"
Assistant: {"is_medical": false, "confidence": "high"}
'''

    @classmethod
    def _get_llm(cls) -> ChatOllama:
        """懒加载 Ollama 意图识别模型。"""
        if cls._llm is None:
            cls._llm = ChatOllama(
                model="qwen3:1.7b",
                base_url="http://localhost:11434",
            )
        return cls._llm

    @classmethod
    def recognize(cls, question: str) -> dict:
        """判断问题是否属于网络安全领域。

        Returns:
            {'is_security': bool, 'confidence': 'high'|'medium'|'low'}
        """
        llm = cls._get_llm()
        rs = llm.invoke([
            {"role": "system", "content": cls._system_prompt},
            {"role": "user", "content": question},
        ])

        try:
            result = json.loads(rs.content)
            print(result)
        except Exception as e:
            result = {}
            print(f"{e}")
        if not isinstance(result, dict):
            result = {}

        return {
            "is_security": bool(result.get("is_security", True)),
            "confidence": result.get("confidence", "low"),
        }
