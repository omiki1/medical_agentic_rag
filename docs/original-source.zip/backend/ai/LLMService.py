"""大模型服务：统一管理 DeepSeek 与 GLM 两类 ChatOpenAI 模型。

合并原 LoadLLM.py（DeepSeek）与 LoadLLM2.py（GLM），
将模块级 `global llm` 收进类属性，提供命名工厂方法。
"""

import os
from pydantic import SecretStr
from langchain_openai import ChatOpenAI


class LLMService:
    """大模型服务（单例）：DeepSeek 与 GLM 各懒加载一次。

    用法：
        deepseek = LLMService.get_deepseek()
        glm      = LLMService.get_glm()
    """

    # 类级缓存：分别缓存 DeepSeek / GLM 模型实例
    _deepseek = None
    _glm = None

    @classmethod
    def get_deepseek(cls) -> ChatOpenAI:
        """获取 DeepSeek 模型（懒加载，进程内只创建一次）。"""
        if cls._deepseek is None:
            cls._deepseek = ChatOpenAI(
                api_key=SecretStr(os.getenv("CHAT_OPENAI_API_KEY")),
                base_url="https://api.deepseek.com",
                model="deepseek-v4-flash",
                streaming=True,
                temperature=0.5,
                top_p=1,
            )
        return cls._deepseek

    @classmethod
    def get_glm(cls) -> ChatOpenAI:
        """获取 GLM 模型（懒加载，进程内只创建一次）。"""
        if cls._glm is None:
            cls._glm = ChatOpenAI(
                api_key=SecretStr(os.getenv("GLM_API_KEY")),
                base_url="https://open.bigmodel.cn/api/paas/v4/",
                model="glm-4.5-air",
                streaming=True,
                temperature=0.5,
                top_p=1,
            )
        return cls._glm

