"""向量存储服务：统一管理 Embedding 模型与 Chroma 向量库连接。

合并原 LoadEmbeddingModel.py 与 LoadChroma.py。
因为 Chroma 需要 embedding 函数，两者天然绑定，放进同一个单例类。
"""

import os
from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

load_dotenv()


class VectorStoreService:
    """向量库服务（单例）：Embedding 模型与 Chroma collection 各懒加载一次。

    用法：
        embed  = VectorStoreService.get_embedding_model()
        chroma = VectorStoreService.get_chroma()
    """

    # 类级缓存
    _embedding = None
    _chroma = None

    @classmethod
    def get_embedding_model(cls) -> HuggingFaceEmbeddings:
        """获取 Embedding 模型（懒加载）。"""
        if cls._embedding is None:
            cls._embedding = HuggingFaceEmbeddings(
                model_name=os.getenv("EMBEDDING_MODEL_PATH"),
                model_kwargs={
                    "device": "cuda",
                    "local_files_only": True,
                },
            )
        return cls._embedding

    @classmethod
    def get_chroma(cls) -> Chroma:
        """获取 Chroma 向量库连接（懒加载，复用 embedding 模型）。"""
        if cls._chroma is None:
            cls._chroma = Chroma(
                collection_name=os.getenv("COLLECTION_NAME"),
                persist_directory=os.getenv("CHROMA_PATH"),
                embedding_function=cls.get_embedding_model(),
            )
        return cls._chroma
