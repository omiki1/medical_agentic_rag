def chat(question: str, historyId: int, username):
    from agent.build_agent import GetAgent
    agent = GetAgent()
    for chunk in agent.run(question):
        yield chunk

if __name__ == '__main__':
    pass
