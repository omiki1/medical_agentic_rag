import random
import os
import requests

from langchain_core.tools import tool
from pydantic import BaseModel, Field


class CQLTool(BaseModel):
    query: str = Field(..., description="Cypher 查询语句，用于查询 Neo4j 医疗知识图谱")


class WeatherTool(BaseModel):
    city: str = Field(..., description="城市名称，如 北京、上海")


class AgentToolbox:
    """
    医疗知识图谱 + 天气 + 动漫角色 工具包。

    注意：LangChain 的 @tool 不能干净地用在带 self 的实例方法上
    （调用时会报 StructuredTool._run() got multiple values for argument 'self'）。
    因此这里在 __init__ 里用「闭包函数」捕获 graph，工具函数本身不写 self。
    """

    def __init__(self, graph):
        self._graph = graph
        self._tools = self._build_tools()

    def _build_tools(self):
        graph = self._graph

        @tool(
            name_or_callable="query_cql",
            description="""
                医疗知识图谱查询工具（Neo4j）。
                当用户询问疾病相关的症状、治疗、药物、饮食等信息时，调用此工具查询知识图谱。

                参数：
                    query：Cypher查询语句

                重要：必须使用以下正确的节点标签和关系类型：

                # 节点标签
                - Disease: 疾病
                - Symptom: 症状
                - Drug: 药物
                - Department: 科室
                - Food: 食物
                - Check: 检查项目

                # 关系类型（必须严格使用以下名称）
                - DISEASE_SYMPTOM: 疾病-症状关系
                - DISEASE_DRUG: 疾病-药物关系
                - DISEASE_DEPARTMENT: 疾病-科室关系
                - DISEASE_DO_EAT: 疾病-推荐食物关系
                - DISEASE_NOT_EAT: 疾病-不推荐食物关系
                - DISEASE_CHECK: 疾病-检查项目关系

                # 正确的查询示例
                查询症状（正确）：
                MATCH (d:Disease)-[:DISEASE_SYMPTOM]->(s:Symptom)
                WHERE d.name CONTAINS '高血压'
                RETURN s.name AS symptom

                查询药物（正确）：
                MATCH (d:Disease)-[:DISEASE_DRUG]->(dr:Drug)
                WHERE d.name = '高血压'
                RETURN dr.name AS drug

                查询科室（正确）：
                MATCH (d:Disease)-[:DISEASE_DEPARTMENT]->(dep:Department)
                WHERE d.name = '高血压'
                RETURN dep.name AS department

                注意：
                - 只使用上述定义的关系类型
                - Symptom 节点只有 name 属性，没有 description 属性
                - 使用 CONTAINS 进行模糊匹配，使用 = 进行精确匹配
            """,
            args_schema=CQLTool,
        )
        def query_cql(query: str):
            """执行Cypher查询并返回结果"""
            print(f'正在查询图数据库')
            return graph.query(query)

        @tool(
            name_or_callable="get_weather",
            description="""
                当用户需要查询某个城市的天气时，调用此工具。
                参数：city，字符串类型，表示城市名称。
            """,
            args_schema=WeatherTool,
        )
        def get_weather(city: str):
            print(f"查询天气的城市：{city}")
            print(f'正在查询天气')
            url = "https://restapi.amap.com/v3/weather/weatherInfo"
            params = {
                "key": os.getenv("WEATHER"),
                "city": city,
                "extensions": "base",  # 返回实时天气
            }
            try:
                rs = requests.get(url, params=params, timeout=10)
                data = rs.json()
                if data.get("status") == "1" and data.get("lives"):
                    live = data["lives"][0]
                    return f"{live['city']}的天气：{live['weather']}，温度：{live['temperature']}℃"
                return f"查询{city}天气失败：{data.get('info', '未知错误')}"
            except Exception as e:
                return f"查询天气时发生错误：{str(e)}"

        @tool(
            name_or_callable="random_character",
            description="""
                当用户想随机抽取一个动漫角色时调用此工具。

                适用场景：
                - 随机一个动漫角色
                - 今日角色
                - 今日老婆
                - 今日老公
                - 给我抽个人物
                - 随便来一个动漫角色

                获取角色结果后，不要只是机械地展示角色资料。
                应结合角色的性格、作品、身份等信息进行轻松有趣的发挥，
                可以生成"今日角色""今日属性""今日Buff""一句吐槽"等娱乐内容。
                整活内容必须明确属于娱乐性发挥，不要把虚构的Buff或评价当成AniList真实数据。
            """,
        )
        def random_character():
            print(f'开始查询角色')
            url = "https://graphql.anilist.co"
            page = random.randint(1, 60)
            graphql_query = """
            query ($page: Int) {
                Page(page: $page, perPage: 20) {
                    characters(sort: FAVOURITES_DESC) {
                        id
                        name { full native }
                        image { large }
                        description
                        gender
                        age
                        favourites
                        media(type: ANIME, perPage: 3, sort: POPULARITY_DESC) {
                            nodes {
                                title { romaji english native }
                                coverImage { medium }
                            }
                        }
                        siteUrl
                    }
                }
            }
            """
            rs = requests.post(
                url,
                json={"query": graphql_query, "variables": {"page": page}},
                timeout=10,
            )
            data = rs.json()
            characters = (
                data.get("data", {})
                .get("Page", {})
                .get("characters", [])
            )
            return random.choice(characters)

        return [query_cql, get_weather, random_character]

    def get_tools(self):
        return self._tools
