from passlib.context import CryptContext

class PasswordManager:
    _crypt_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    @classmethod
    def hash_password(cls, plain_password: str) -> str:
        """
        对明文密码进行哈希处理。

        Args:
            plain_password: 明文密码字符串。

        Returns:
            一个包含算法、工作因子、盐值和哈希值的完整字符串（Modular Crypt Format），
            可以直接存储在数据库中。
        """
        return cls._crypt_context.hash(plain_password)

    @classmethod
    def verify_password(cls, plain_password: str, hashed_password: str) -> bool:
        """
        验证明文密码与哈希密码是否匹配。

        Args:
            plain_password: 用户输入的明文密码。
            hashed_password: 从数据库中取出的完整哈希密码字符串。

        Returns:
            如果匹配返回 True，否则返回 False。
        """
        return cls._crypt_context.verify(plain_password, hashed_password)